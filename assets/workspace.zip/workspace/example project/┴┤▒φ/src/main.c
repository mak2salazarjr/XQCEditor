#include <stdio.h>
#include <string.h>
#include "List/LinkedList.h"

int sortList(const void*a,const void*b)
{
	return strcmp(a,b);
}
/*
by望尘11
使用封装好的链表
*/
int main()
{
	LinkedList * list = newLinkedList();//创建链表
	//添加元素
	LinkedList_addLast(list,"456");
	LinkedList_addLast(list,"123");
	LinkedList_addLast(list,"234");
	LinkedList_addLast(list,"789");
	LinkedList_addLast(list,"678");
	printf("排序前\n");
	//输出元素
	for(int i=0;i<LinkedList_size(list);i++)
	{
		printf("%s\n",(char *)LinkedList_get(list,i));
	}
	printf("排序后\n");
	LinkedList_sort(list,sortList);//使用比较函数sortList进行排序
	for(int i=0;i<LinkedList_size(list);i++)
	{
		printf("%s\n",(char *)LinkedList_get(list,i));
	}
	
	deleteLinkedList(list);//删除链表
	return 0;
}