#include <stdio.h>
#include <math.h>
#include <time.h>
#include "mstring.h"
#include "mlinkedlist.h"


//by 望尘11 

void testMString();
void testMLinkedList();

int main(int argc,char **argv)
{
	testMString();
	testMLinkedList();
	
	checkMStringNumber();
	checkMLinkedListNumber();
	return 0;
}


void testMString()
{
	MString *str1=createString("Hello World! by wangchen11!\n");
	MLinkedList *splitedStrings = MStringSplit(str1," ");//通过空格来分割字符串 
	MLinkedListIteratorStart(splitedStrings);//使用迭代器之前需要调用这个 
	while(MLinkedListIteratorHasNext(splitedStrings))
	{
		//这里得到的string对象不需要delete,因为它在list里面还有引用
		MString *tempString=MLinkedListIteratorGetNext(splitedStrings);
		printf("%s\n",tempString->mStr);
	}
	deleteLinkedList(splitedStrings);
	deleteString(str1);
}


void testMLinkedList()
{
	printf("testMLinkedList\n");
	char buffer[100];
	srand(time(0));
	MLinkedList *stringList=createSyncLinkedList(deleteString);
	for(int i=0;i<1000;i++)
	{
		sprintf(buffer,"%d",rand()%1000);
		MLinkedListAdd(stringList,createString(buffer));
	}
	
	printf("排序前:\n");
	MLinkedListIteratorStart(stringList);
	int n=0;
	while(MLinkedListIteratorHasNext(stringList))
	{
		MString *tempString= MLinkedListIteratorGetNext(stringList);
		if( (n++)%10==0)
			printf("\n");
		printf("%s\t",tempString->mStr);
	}
	printf("\n");
	
	MLinkedListSort(stringList,(FunctionPointer_compare)MStringCompare);
	
	printf("\n排序后:\n");
	MLinkedListIteratorStart(stringList);
	while(MLinkedListIteratorHasNext(stringList))
	{
		MString *tempString= MLinkedListIteratorGetNext(stringList);
		if( (n++)%10==0)
			printf("\n");
		printf("%s\t",tempString->mStr);
	}
	printf("\n");
	deleteLinkedList(stringList);
}
