#include "mobject.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void *_mnew(int size)
{
	void *object=malloc(size);
	if(object==null)
		makeError("_mnew,out of memory!");
	else
		memset(object,0,size);
	return object;
}

//产生一个错误，在程序跑飞之前终止程序
void makeError(const char *tag)
{
	int a=0;
	if(tag!=null)
		printf("error:%s !\n",tag);
	else
		printf("error!\n");
	a=1/a;//产生一个除0错误 
}
