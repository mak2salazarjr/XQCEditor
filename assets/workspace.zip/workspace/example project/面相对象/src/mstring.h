#ifndef MSTRING_H
#define MSTRING_H
#include "mobject.h"
#include "mlinkedlist.h"

typedef struct MString_st{
	int mLength;
	char *mStr;
}MString;

extern int checkMStringNumber();
extern MString *createString(const char *str);
extern MString *createString1(const char *str,int offset,int length);
extern MString *createString2(int length);
extern void deleteString(MString *string);
extern int MStringCompare(MString *mthis,MString *other);
extern char MStringCharAt(MString *mthis,int at);
extern int MStringIndexOf(MString *mthis,const char *other);
extern MString *MStringSubString(MString *mthis,int offset,int endset);
extern MString *MStringAppend(MString *mthis,const char *other);
extern MString *MStringAppend1(MString *mthis,MString *other);
extern void deleteStringArray(MString **strings);
extern MLinkedList *MStringSplit(MString *mthis,const char *splitBy);
extern MLinkedList *MStringSplit1(MString *mthis,MString *splitBy);


#endif

