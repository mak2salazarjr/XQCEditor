#ifndef MOBJECT_H
#define MOBJECT_H

#include <stdlib.h>
#define null NULL 
typedef char boolean;
#define true 1 
#define false 0  
#define mnew(t) ((t*)_mnew(sizeof(t)))
extern void *_mnew(int size);
extern void makeError(const char *tag);

#endif


