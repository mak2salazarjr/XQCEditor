#include "mstring.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/*
字符串类
by望尘11
*/
static int mNumberOfUsingStrings = 0;
int checkMStringNumber()
{
	printf("mNumberOfUsingStrings:%d\n",mNumberOfUsingStrings);
	return mNumberOfUsingStrings; 
}

MString *createString(const char *str)
{
	if(str==null)
	{
		makeError("createString, str is null!");
	}
	else
	{
		return createString1(str,0,strlen(str));
	}
	return null;
}

MString *createString1(const char *str,int offset,int length)
{
	int len;
	MString *string=null;
	len=strlen(str);
	if(str==null)
	{
		makeError("createString1, str is null!");
	}
	else
	if(offset<0||offset+length>len)
	{
		printf("strlen=%d,offset=%d,length=%d\n",len,offset,length);
		makeError("createString1, out of bounds!");
	}
	else
	{
		string=createString2(length);
		strncpy(string->mStr,str+offset,string->mLength);
	}
	return string;
}

MString *createString2(int length)
{
	//printf("createString2:%d\n",length);
	MString *string=null;
	mNumberOfUsingStrings++; 
	string=mnew(MString);
	string->mLength=length;
	string->mStr=malloc(string->mLength+1);
	string->mStr[0]=0;
	string->mStr[length]=0;
	//printf("createString2ED:%d\n",length);
	return string;
}

void deleteString(MString *string)
{
	if(string==null)
		makeError("deleteString, string is null");
	else
	{
		if(string->mStr==null)
		{
			makeError("deleteString, string->mStr is null");
		}
		else 
		{
			//printf("free:%s\n",string->mStr);
			free(string->mStr);
			string->mStr=null;
		}
		mNumberOfUsingStrings--; 
		string->mLength=0;
		free(string);
	}
}



void deleteStringArray(MString **strings)
{
	int i=0;
	if(strings==null)
		makeError("deleteStringArray, strings is null");
	else
	{
		for(i=0;strings[i]!=null;i++)
		{
			deleteString(strings[i]);
			strings[i]=null;
		}
		free(*strings);
	}
}

int MStringCompare(MString *mthis,MString *other)
{
	int ret=0;
	if(mthis==null)
		makeError("MStringCharAt, mthis is null!");
	else
	if(other==null)
		makeError("MStringCharAt, other is null!");
	else
	{
		ret=strcmp(mthis->mStr,other->mStr);
	}
	return ret;
}

char MStringCharAt(MString *mthis,int at)
{
	if(mthis==null)
		makeError("MStringCharAt, mthis is null!");
	else
	if(at<0||at>=mthis->mLength)
	{
		printf("string->mLength=%d,at=%d\n",mthis->mLength,at);
		makeError("MStringCharAt, out of bounds!");
	}
	else
	{
		return mthis->mStr[at];
	}
	return 0;
}

int MStringIndexOf(MString *mthis,const char *other)
{
	int ret=-1;
	char *find=null;
	if(mthis==null)
		makeError("MStringIndexOf, mthis is null!");
	else
	if(other==null)
		makeError("MStringIndexOf, other is null!");
	else
	{
		if(mthis->mStr!=null)
		{
			find=strstr(mthis->mStr,other);
			if(find!=null)
				ret=find-mthis->mStr;
		}
	}
	return ret;
}

MString *MStringSubString(MString *mthis,int offset,int length)
{
	if(mthis==null)
		makeError("MStringSubString, mthis is null!");
	else
	{
		return createString1(mthis->mStr,offset,length);
	}
	return null;
}

MString *MStringAppend(MString *mthis,const char *other)
{
	MString *ret=null;
	MString *otherString=null;
	otherString=createString(other);
	ret=MStringAppend1(mthis,otherString);
	deleteString(otherString);
	return ret;
}

MString *MStringAppend1(MString *mthis,MString *other)
{
	MString *ret=null;
	if(mthis==null)
		makeError("MStringAppend1, mthis is null!");
	else
	if(other==null)
		makeError("MStringAppend1, other is null!");
	else
	{
		ret=createString2(mthis->mLength+other->mLength);
		strncpy(ret->mStr,mthis->mStr,mthis->mLength);
		strncpy(ret->mStr+mthis->mLength,other->mStr,other->mLength);
	}
	return ret;
}

MLinkedList *MStringSplit(MString *mthis,const char *splitBy)
{
	MLinkedList *LinkedList=null;
	MString *slpitString=null;
	slpitString=createString(splitBy);
	LinkedList=MStringSplit1(mthis,slpitString);
	deleteString(slpitString);
	return LinkedList;
}

MLinkedList *MStringSplit1(MString *mthis,MString *splitBy)
{
	MLinkedList *linkedList=null;
	MString *tempString=null;
	char *index=null;
	char *pos=null;
	if(mthis==null)
		makeError("MStringSplitExps, mthis is null!");
	else
	if(splitBy==null)
		makeError("MStringSplitEx, splitBy is null!");
	else
	{
		linkedList=createLinkedList(deleteString);
		pos=mthis->mStr;
		while( (index=strstr(pos,splitBy->mStr))!=null )
		{
			tempString=createString1(pos,0,index-pos);
			MLinkedListAdd(linkedList,tempString);
			pos=index+splitBy->mLength;
		}
		if(pos!=null)
		{
			tempString=createString1(pos,0,strlen(pos));
			MLinkedListAdd(linkedList,tempString);
			pos=null;
		}
	}
	return linkedList;
}
