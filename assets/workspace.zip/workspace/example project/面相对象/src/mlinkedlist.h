/*
 * wangchen11 software.
 */

#ifndef MLINKEDLIST_H
#define MLINKEDLIST_H
#include <pthread.h>
#include "mobject.h"

/*
定义删除一个数据的函数指针
*/
typedef void (*FunctionPointer_delete)(void *object);
/*
定义比较两个数据的函数指针，用于排序
*/
typedef int (*FunctionPointer_compare)(void *object1,void *object2);

/*
定义节点数据结构
*/
typedef struct MLinkedListNode_st{
	void *object;
	struct MLinkedListNode_st *pro;
	struct MLinkedListNode_st *next;
}MLinkedListNode;

/*
定义链表数据结构
*/
typedef struct MLinkedList_st{
	FunctionPointer_delete mOnDleteObject;
	int mLength;
	MLinkedListNode *mFrist;
	MLinkedListNode *mLast;
	MLinkedListNode *mNow;
	
	MLinkedListNode *_cacheNode;
	int _cachePosition;
	pthread_mutex_t *_lock;
}MLinkedList;

/*
检查是否存在泄露 
*/
extern int checkMLinkedListNumber();

/*
创建一个链表，fp为释放一个数据的函数指针。以便链表在需要时释放。
*/
#define createLinkedList(fp) _createLinkedList((FunctionPointer_delete)fp)

/*
创建一个链表，fp为释放一个数据的函数指针。以便链表在需要时释放。
*/
extern MLinkedList *_createLinkedList(FunctionPointer_delete onDelete);

/*
创建一个同步链表，fp为释放一个数据的函数指针。以便链表在需要时释放。
该方法创建的链表适合多线程中访问。
*/
#define createSyncLinkedList(fp) _createSyncLinkedList((FunctionPointer_delete)fp)

/*
创建一个同步链表，fp为释放一个数据的函数指针。以便链表在需要时释放。
该方法创建的链表适合多线程中访问。
*/
extern MLinkedList *_createSyncLinkedList(FunctionPointer_delete onDelete);

/*
删除整个链表，会调用创建链表时传入的删除函数来挨个释放所有的数据，如果删除函数为空，则不调用
调用后，此链表将不可再使用。
*/
extern void deleteLinkedList(MLinkedList* linkedList);

/*
删除链表中的一个节点，并调用删除函数来释放这个数据。如果删除函数为空，则不调用
*/
extern void MLinkedListRemove(MLinkedList* mthis,int position);

/*
清空整个链表，删除其中的所有数据。但不删除链表本身。
调用后，此链表还可以继续使用。
*/
extern void MLinkedListRemoveAll(MLinkedList* mthis);

/*
删除整个链表,但是不释放其中数据的内存。
调用后，此链表将不可再使用。
*/
extern void deleteLinkedListWithOutFree(MLinkedList* linkedList);

/*
删除链表中的一个节点，但是不释放其数据的内存。
返回删除位置的数据。
*/
extern void *MLinkedListRemoveWithOutFree(MLinkedList* mthis,int position);

/*
清空整个链表，但是不释放其数据的内存。则不删除链表本身。
调用后，此链表还可以继续使用。
*/
extern void MLinkedListRemoveAllWithOutFree(MLinkedList* mthis);

/*
向链表中添加一个数据(添加到末尾)。
*/
extern void MLinkedListAdd(MLinkedList* mthis,void *object);

/*
向链表末尾添加一个数据。
*/
extern void MLinkedListAddLast(MLinkedList* mthis,void *object);

/*
向链表开始位置添加一个数据。
*/
extern void MLinkedListAddFrist(MLinkedList* mthis,void *object);

/*
开始迭代。使用迭代器，要比通过位置找节点效率高。
*/
extern void MLinkedListIteratorStart(MLinkedList* mthis);

/*
判断迭代器是否还有下一个数据
*/
extern boolean MLinkedListIteratorHasNext(MLinkedList* mthis);

/*
得到迭代器的下一个数据。
*/
extern void *MLinkedListIteratorGetNext(MLinkedList* mthis);

/*
排序整个链表。通过传入的比较函数来比较每个节点，并排序(采用的是冒泡排序)。
*/
extern void MLinkedListSort(MLinkedList* mthis,FunctionPointer_compare onCompare);

/*
排序整个链表。通过传入的比较函数来比较每个节点，并排序(采用的是冒泡排序)。
此函数为测试函数，效率比上面那个要低。
*/
extern void MLinkedListSortTEST(MLinkedList* mthis,FunctionPointer_compare onCompare);

/*
得到第postion个元素。
*/
extern void *MLinkedListGet(MLinkedList* mthis,int position);

/*
查找object在链表中的位置，通过onCompare来比较，如果onCompare返回0则返回该元素的位置。
如果onCompare==null那么仅仅比较两个数据的指针。
*/
extern int MLinkedListIndexOf(MLinkedList* mthis,void *object,FunctionPointer_compare onCompare);

/*
交换两个位置的数据
*/
extern void MLinkedListChangeObject(MLinkedList* mthis,int position1,int position2);

#endif

