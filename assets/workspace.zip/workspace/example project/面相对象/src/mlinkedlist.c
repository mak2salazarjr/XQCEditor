#include "mlinkedlist.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

/*
链表
by望尘11
*/

static int mNumberOfLinkedList=0;
static int mNumberOfLinkedNode=0;

static MLinkedListNode *_getNode(MLinkedList* mthis,int postion);
static void _remove(MLinkedList* mthis,MLinkedListNode *findNode,boolean needFree);
static void _insertToNext(MLinkedList* mthis,MLinkedListNode *node,MLinkedListNode *next);
static void _insertToPro(MLinkedList* mthis,MLinkedListNode *node,MLinkedListNode *pro);
static void _changeObject(MLinkedList* mthis,MLinkedListNode *node1,MLinkedListNode *node2); 

//简单的检查对象是否存在泄漏
int checkMLinkedListNumber()
{
	printf("mNumberOfLinkedList:%d\n",mNumberOfLinkedList);
	printf("mNumberOfLinkedNode:%d\n",mNumberOfLinkedNode);
	return mNumberOfLinkedList+mNumberOfLinkedNode;
}

MLinkedList *_createLinkedList(FunctionPointer_delete onDelete)
{
	MLinkedList *linkedList=null;
	if(onDelete==null)
	{
		makeError("_createLinkedList,onDelete==null!");
	}
	else
	{
		linkedList=mnew(MLinkedList);
		linkedList->mOnDleteObject=onDelete;
		linkedList->mLength=0;
		linkedList->mFrist=null;
		linkedList->mLast=null;
		linkedList->mNow=null;
		mNumberOfLinkedList++;
	}
	return linkedList;
}

MLinkedList *_createSyncLinkedList(FunctionPointer_delete onDelete)
{
	MLinkedList *linkedList=null;
	linkedList = createLinkedList(onDelete);
	if(linkedList==null)
		return null;
	//创建锁 
	//printf("create lock\n");
	linkedList->_lock = mnew(pthread_mutex_t);
	pthread_mutex_init(linkedList->_lock,null);
	return linkedList;
}

void deleteLinkedList(MLinkedList* linkedList)
{
	//if()
	MLinkedListRemoveAll(linkedList);
	if(linkedList->_lock!=null)
	{
		//printf("free lock\n");
		pthread_mutex_destroy(linkedList->_lock);
		free(linkedList->_lock);
	}
	memset(linkedList,0,sizeof(MLinkedList));
	free(linkedList);
	mNumberOfLinkedList--;
}

void MLinkedListRemove(MLinkedList* mthis,int position)
{
	if(mthis->_lock!=null)
		pthread_mutex_lock(mthis->_lock);
	MLinkedListNode *findNode=null;
	if(mthis==null)
	{
		makeError("MLinkedListRemove, mthis is null");
	}
	else
	if(position<0||position>=mthis->mLength)
	{
		printf("mthis->mLength:%d,position:%d\n",mthis->mLength,position);
		makeError("MLinkedListRemove, out of bounds!");
	}
	else
	{
		findNode=_getNode(mthis,position);
		if(findNode==null)
		{
			makeError("MLinkedListRemove, findNode is null!");
		}
		else
		{
			_remove(mthis,findNode,true);
		}
	}
	if(mthis->_lock!=null)
		pthread_mutex_unlock(mthis->_lock);
}

void MLinkedListRemoveAll(MLinkedList* mthis)
{
	if(mthis==null)
	{
		makeError("MLinkedListRemove, mthis is null");
	}
	else
	{
		while(mthis->mFrist!=null)
		{
			MLinkedListRemove(mthis,0);
		}
	}
}


void deleteLinkedListWithOutFree(MLinkedList* linkedList)
{
	MLinkedListRemoveAllWithOutFree(linkedList);
	if(linkedList->_lock!=null)
	{
		//printf("free lock\n");
		pthread_mutex_destroy(linkedList->_lock);
		free(linkedList->_lock);
	}
	memset(linkedList,0,sizeof(MLinkedList));
	free(linkedList);
	mNumberOfLinkedList--;
}

void *MLinkedListRemoveWithOutFree(MLinkedList* mthis,int position)
{
	if(mthis->_lock!=null)
		pthread_mutex_lock(mthis->_lock);
	MLinkedListNode *findNode=null;
	void *object=null;
	if(mthis==null)
	{
		makeError("MLinkedListRemoveWithOutFree, mthis is null");
	}
	else
	if(position<0||position>=mthis->mLength)
	{
		printf("mthis->mLength:%d,position:%d\n",mthis->mLength,position);
		makeError("MLinkedListRemoveWithOutFree, out of bounds!");
	}
	else
	{
		findNode=_getNode(mthis,position);
		if(findNode==null)
		{
			makeError("MLinkedListRemove, findNode is null!");
		}
		else
		{
			object=findNode->object;
			_remove(mthis,findNode,false);
		}
	}
	if(mthis->_lock!=null)
		pthread_mutex_unlock(mthis->_lock);
	return object;
}

void MLinkedListRemoveAllWithOutFree(MLinkedList* mthis)
{
	if(mthis==null)
	{
		makeError("MLinkedListRemove, mthis is null");
	}
	else
	{
		while(mthis->mFrist!=null)
		{
			MLinkedListRemoveWithOutFree(mthis,0);
		}
	}
}


void MLinkedListAdd(MLinkedList* mthis,void *object)
{
	MLinkedListAddLast(mthis,object);
}

void MLinkedListAddLast(MLinkedList* mthis,void *object)
{
	if(mthis->_lock!=null)
		pthread_mutex_lock(mthis->_lock);
	MLinkedListNode *node;
	if(mthis==null)
	{
		makeError("MLinkedListAddLast, mthis is null");
	}
	else
	{
		node=mnew(MLinkedListNode);
		node->object=object;
		_insertToNext(mthis,mthis->mLast,node);
	}
	if(mthis->_lock!=null)
		pthread_mutex_unlock(mthis->_lock);
}

void MLinkedListAddFrist(MLinkedList* mthis,void *object)
{
	if(mthis->_lock!=null)
		pthread_mutex_lock(mthis->_lock);
	MLinkedListNode *node;
	if(mthis==null)
	{
		makeError("MLinkedListAddFrist, mthis is null");
	}
	else
	{
		node=mnew(MLinkedListNode);
		node->object=object;
		_insertToPro(mthis,mthis->mFrist,node);
	}
	if(mthis->_lock!=null)
		pthread_mutex_unlock(mthis->_lock);
}

/**
 * 迭代器开始
 */
void MLinkedListIteratorStart(MLinkedList* mthis)
{
	if(mthis==null)
	{
		makeError("MLinkedListIteratorStart, mthis is null");
	}
	else
	{
		mthis->mNow=mthis->mFrist;
	}
}

/*
 * 使用前必须先开始迭代器: MLinkedListIteratorStart 
 */
boolean MLinkedListIteratorHasNext(MLinkedList* mthis)
{
	if(mthis==null)
	{
		makeError("MLinkedListIteratorStart, mthis is null");
	}
	else
	{
		return mthis->mNow!=null;
	}
	return false;
}


void *MLinkedListIteratorGetNext(MLinkedList* mthis)
{
	if(mthis->_lock!=null)
		pthread_mutex_lock(mthis->_lock);
	void *ret=null;
	if(mthis==null)
	{
		makeError("MLinkedListIteratorStart, mthis is null");
	}
	else
	{
		if(mthis->mNow==null)
		{
			makeError("MLinkedListIteratorGetNext, mthis->mNow is null");
		}
		else
		{
			ret = mthis->mNow->object;
			mthis->mNow=mthis->mNow->next;
		}
	}
	if(mthis->_lock!=null)
		pthread_mutex_unlock(mthis->_lock);
	return ret;
}

/**
 * 冒泡排序
 */
void MLinkedListSort(MLinkedList* mthis,FunctionPointer_compare onCompare)
{
	if(mthis->_lock!=null)
		pthread_mutex_lock(mthis->_lock);
	MLinkedListNode *node1=null;
	MLinkedListNode *node2=null;
	MLinkedListNode *pos1=null;
	MLinkedListNode *pos2=null;
	int cmp;
	if(mthis==null)
		makeError("MLinkedListSort, mthis is null");
	else
	if(onCompare==null)
		makeError("MLinkedListSort, onCompare is null");
	else
	{
		for(pos1=mthis->mLast;pos1->pro!=null;pos1=pos1->pro)
		{
			for(pos2=mthis->mFrist;pos2!=pos1;pos2=pos2->next)
			{
				node1=pos2;
				node2=pos2->next;
				cmp=onCompare(node1->object,node2->object);
				if(cmp>0)
				{
					_changeObject(mthis,node1,node2);
				}
			}
		}
	}
	if(mthis->_lock!=null)
		pthread_mutex_unlock(mthis->_lock);
}


void MLinkedListSortTEST(MLinkedList* mthis,FunctionPointer_compare onCompare)
{
	if(mthis->_lock!=null)
		pthread_mutex_lock(mthis->_lock);
	int i,j;
	int cmp;
	if(mthis==null)
		makeError("MLinkedListSort, mthis is null");
	else
	if(onCompare==null)
		makeError("MLinkedListSort, onCompare is null");
	else
	{
		for(i=mthis->mLength-1;i>=0;i--)
		{
			for(j=0;j<i;j++)
			{
				MLinkedListNode *node1=null;
				MLinkedListNode *node2=null;
				node1=_getNode(mthis,j);
				node2=_getNode(mthis,j+1);
				cmp=onCompare(node1->object,node2->object);
				if(cmp>0)
				{
					_changeObject(mthis,node1,node2);
				}
			}
		}
	}
	if(mthis->_lock!=null)
		pthread_mutex_unlock(mthis->_lock);
}

void *MLinkedListGet(MLinkedList* mthis,int position)
{
	if(mthis->_lock!=null)
		pthread_mutex_lock(mthis->_lock);
	MLinkedListNode *node=null;
	if(mthis==null)
		makeError("MLinkedListGet, mthis is null");
	else
	if(position<0||position>=mthis->mLength)
	{
		printf("mthis->mLength=%d,position=%d\n",mthis->mLength,position);
		makeError("MLinkedListGet, out of bounds!");
	}
	else
		node = _getNode(mthis,position);
	if(mthis->_lock!=null)
		pthread_mutex_unlock(mthis->_lock);
	if(node!=null)
		return node->object;
	return null;
}

int MLinkedListIndexOf(MLinkedList* mthis,void *object,FunctionPointer_compare onCompare)
{
	if(mthis->_lock!=null)
		pthread_mutex_lock(mthis->_lock);
	int index=-1;
	MLinkedListNode *pos=null;
	if(mthis==null)
		makeError("MLinkedListIndexOf, mthis is null");
	//else
	//if(onCompare==null)
	//	makeError("MLinkedListIndexOf, onCompare is null");
	else
	{
		for(pos=mthis->mFrist;pos!=null;pos=pos->next)
		{
			index++;
			if( onCompare==null )
			{
				if(pos->object == object)
					return index;
			}
			else
			if( onCompare(pos->object,object)==0 )
			{
				return index;
			}
		}
	}
	if(mthis->_lock!=null)
		pthread_mutex_unlock(mthis->_lock);
	return -1;
}

void MLinkedListChangeObject(MLinkedList* mthis,int position1,int position2)
{
	if(mthis->_lock!=null)
		pthread_mutex_lock(mthis->_lock);
	_changeObject(mthis,_getNode(mthis,position1),_getNode(mthis,position2));
	if(mthis->_lock!=null)
		pthread_mutex_unlock(mthis->_lock);
}



static MLinkedListNode *_getNode(MLinkedList* mthis,int position)
{
	int index=0;
	MLinkedListNode *ret=null;
	ret=mthis->mFrist;
	int distanceToFrist=abs(position-0);
	int distanceToLast=abs(position-(mthis->mLength-1));
	int distanceToCache=abs(position-(mthis->_cachePosition));
	if(distanceToFrist<=distanceToLast)
	{
		if(distanceToFrist<=distanceToCache)
		{
			//printf("get 1#\t%d\n",distanceToFrist);
			ret=mthis->mFrist;
			for(index=0;index!=position;index++)
			{
				if(ret==null)
					break;
				ret=ret->next;
			}
		}
		else
		{
			ret=mthis->_cacheNode;
			if(position-mthis->_cachePosition>=0)
			{
				//printf("get 2.1#\t%d\n",distanceToCache);
				for(index=mthis->_cachePosition;index!=position;index++)
				{
					if(ret==null)
						break;
					ret=ret->next;
				}
			}
			else
			{
				//printf("get 2.2#\t%d\n",distanceToCache);
				for(index=mthis->_cachePosition;index!=position;index--)
				{
					if(ret==null)
						break;
					ret=ret->pro;
				}
			}
		}
	}
	else
	{
		if(distanceToLast<=distanceToCache)
		{
			//printf("get 3#\t%d\n",distanceToLast);
			ret=mthis->mLast;
			for(index=mthis->mLength-1;index!=position;index--)
			{
				if(ret==null)
					break;
				ret=ret->pro;
			}
		}
		else
		{
			ret=mthis->_cacheNode;
			if(position-mthis->_cachePosition>=0)
			{
				//printf("get 4.1#\t%d\n",distanceToCache);
				for(index=mthis->_cachePosition;index!=position;index++)
				{
					if(ret==null)
						break;
					ret=ret->next;
				}
			}
			else
			{
				//printf("get 4.2#\t%d\n",distanceToCache);
				for(index=mthis->_cachePosition;index!=position;index--)
				{
					if(ret==null)
						break;
					ret=ret->pro;
				}
			}
		}
	}
	if(ret==null)
	{
		makeError("at _getNode:ret==null!");
	}
	else
	{
		mthis->_cacheNode=ret;
		mthis->_cachePosition=position;
	}
	return ret;
}

static void _remove(MLinkedList* mthis,MLinkedListNode *findNode,boolean needFree)
{
	//printf("_remove\n");
	MLinkedListNode *findNodePro=null;
	MLinkedListNode *findNodeNext=null;
	if(findNode==mthis->mFrist)
	{
		mthis->mFrist=findNode->next;
	} 
	if(findNode==mthis->mLast)
	{
		mthis->mLast=findNode->pro;
	}
	if(findNode==mthis->mNow)
	{
		mthis->mNow=findNode->next;
	}
	findNodePro=findNode->pro;
	findNodeNext=findNode->next;
	if(findNodePro!=null)
		findNodePro->next=findNodeNext;
	if(findNodeNext!=null)
		findNodeNext->pro=findNodePro;
	if(mthis->mOnDleteObject!=null&&needFree)
	{
		mthis->mOnDleteObject(findNode->object);
	}
	memset(findNode,0,sizeof(MLinkedListNode));
	free(findNode);
	mthis->mLength--;
	mNumberOfLinkedNode--;
	mthis->_cachePosition=0;
	mthis->_cacheNode=mthis->mFrist;
}

static void _insertToNext(MLinkedList* mthis,MLinkedListNode *node,MLinkedListNode *next)
{
	//printf("_insertToNext\n");
	if(next==null)
		makeError("_insertToNext, next is null");
	mNumberOfLinkedNode++;
	mthis->mLength++;
	if(mthis->mFrist==null)
	{
		mthis->mFrist=next;
		mthis->mLast=next;
		return ;
	}
	if(node==null)
		makeError("_insertToNext, mthis is not empty but node is null!");
	next->next=node->next;
	if(next->next!=null)
		next->next->pro=next;
	next->pro=node;
	node->next=next;
	if(node==mthis->mLast)
	{
		mthis->mLast=next;
	}
	mthis->_cachePosition=0;
	mthis->_cacheNode=mthis->mFrist;
}

static void _insertToPro(MLinkedList* mthis,MLinkedListNode *node,MLinkedListNode *pro)
{
	//printf("_insertToPro\n");
	if(pro==null)
		makeError("_insertToPro, pro is null");
	mthis->mLength++;
	mNumberOfLinkedNode++;
	if(mthis->mFrist==null)
	{
		mthis->mFrist=pro;
		mthis->mLast=pro;
		return ;
	}
	if(node==null)
		makeError("_insertToPro, mthis is not empty but node is null!");
	pro->pro=node->pro;
	if(pro->pro!=null)
		pro->pro->next=pro;
	pro->next=node;
	node->pro=pro;
	if(node==mthis->mFrist)
	{
		mthis->mFrist=pro;
	}
	mthis->_cachePosition=0;
	mthis->_cacheNode=mthis->mFrist;
}

/**
 * 交换数据
 */ 
static void _changeObject(MLinkedList* mthis,MLinkedListNode *node1,MLinkedListNode *node2)
{
	void *object=node1->object;
	node1->object=node2->object;
	node2->object=object;
}



