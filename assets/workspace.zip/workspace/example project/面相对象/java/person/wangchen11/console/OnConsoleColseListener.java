package person.wangchen11.console;

public interface OnConsoleColseListener {
	public void onConsoleClose(Console console);
}
