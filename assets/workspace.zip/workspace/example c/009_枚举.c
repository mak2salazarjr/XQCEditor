#include <stdio.h>

enum //枚举
{
	ZERO,	//编译器为其分配0后面的定位依次递增
	ONE,	//1
	TWO,	//2
	THREE,	//3
	SIX=6,	//手动赋值6后从这个值往后递增
	SEVEN,	//7
	
};

int main()
{
	printf("%d %d %d %d %d %d\n",ZERO,ONE,TWO,THREE,SIX,SEVEN);
	return 0;
}