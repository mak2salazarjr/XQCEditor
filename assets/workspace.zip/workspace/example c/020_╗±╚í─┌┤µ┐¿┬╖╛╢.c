#include <stdio.h>
#include <stdlib.h>

int main()
{
	char *sdcardPath=getenv("EXTERNAL_STORAGE");
	printf("内存卡路径:%s",sdcardPath);
	return 0;
}