#include <stdio.h>

int add(int a,int b){
	int ret = 0;
	int flag = 0;
	int xorb = 0x1;
	while(xorb!=0)
	{
		ret|=(a&xorb)^(b&xorb)^flag;
		if(((a&xorb&b&xorb)!=0)||((a&xorb&flag)!=0)||((b&xorb&flag)!=0)){
			//有进位,这个式子可以化简，但是这部分知识已经还给老师了 
			flag = xorb<<1;
		}
		else
		{
			flag = 0;
		}
		xorb<<=1;
	}
	return ret;
}

int sub(int a,int b){
	return add(a,add(~b,1));
}

int div(int dividend,int divisor)
{
	if(divisor==0)//除数为0异常 
		return 0;
	if(dividend<0)
		return -div(-dividend,divisor);
	if(divisor<0)
		return -div(dividend,-divisor);
	int result = 0;
	int n_2 = 2;
	int temp;
	while(dividend>=divisor)
	{
		temp = divisor<<n_2;
		if(dividend>=temp)
		{
			dividend-=temp;
			result+=1<<n_2;
			n_2++;
		}
		else
		{
			n_2--;
		}
	}
	return result;
}

int main()
{
	int a=1265;
	int b=1560;
	printf("%d,%d\n",a+b,add(a,b));
	printf("%d,%d\n",a-b,sub(a,b));
	printf("%d,%d\n",a/b,div(a,b));

	return 0;
}