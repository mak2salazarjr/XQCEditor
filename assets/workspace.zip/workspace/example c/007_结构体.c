#include <stdio.h>
#include <string.h>
/*
定义日期结构
*/
struct data_st {
	int year;//年
	int month;//月
	int day;//日
};

/*
定义学生结构
*/
struct student_st{
	int studentNumber;//学号
	char name[10];//姓名
	struct data_st buthday;//生日
};

void showStudent1(struct student_st student);

void showStudent2(struct student_st* student);

int main()
{
	struct student_st student;
	student.studentNumber = 1000001;
	strcpy(student.name,"望尘11");
	student.buthday.year = 1994;
	student.buthday.month = 4;
	student.buthday.day = 28;
	showStudent1(student);
	showStudent2(&student);
	return 0;
}


void showStudent1(struct student_st student)
{
	printf("显示方法1:\n");
	printf("姓名:%s\n",student.name);
	printf("学号:%d\n",student.studentNumber);
	printf("生日:%d.%d.%d\n",student.buthday.year  ,student.buthday.month  ,student.buthday.day);
}

void showStudent2(struct student_st* student)
{
	printf("显示方法2:\n");
	printf("姓名:%s\n",student->name);
	printf("学号:%d\n",student->studentNumber);
	printf("生日:%d.%d.%d\n",student->buthday.year  ,student->buthday.month  ,student->buthday.day);
}
