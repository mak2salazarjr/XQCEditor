#include <stdio.h>

//by 望尘11

//输出数组
void printArray(int array[],int arrayLen);

int main()
{
	int array[]={
		-90,60,54,76,88,102,67,679,451,-6,0,102
	};
	int arrayLen = sizeof(array) / sizeof(int); //计算数组长度
	printf("排序前:\n");
	printArray(array,arrayLen);
	
	for(int i=arrayLen-1;i>0;i--)
	{
		for(int j=0;j<i;j++)
		{
			if(array[j]>array[j+1])
			{//交换 位于j和j+1 的元素
				int temp;
				temp = array[j];
				array[j]=array[j+1];
				array[j+1]=temp;
			}
		}
	}
	
	printf("排序后:\n");
	printArray(array,arrayLen);
	return 0;
}

//输出数组
void printArray(int array[],int arrayLen)
{
	for(int i=0;i<arrayLen;i++)
	{
		printf("%d\t",array[i]);
	}
	printf("\n");
}