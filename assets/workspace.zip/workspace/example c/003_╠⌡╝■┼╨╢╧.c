#include <stdio.h>

/*
by 望尘11
*/

int main(void)
{
	int a=0,b=0;
	int max=0;
	printf("请输入两个数以判断最大的一个数\n");
	scanf("%d%d",&a,&b);
	if(a>b)
		max=a;
	else
		max=b;
	printf("最大的一个数为:%d\n",max);
	return 0;
}