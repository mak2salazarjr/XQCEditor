#include <iostream>
using namespace std;

class TestClass{
public:
	TestClass()
	{
	}
	
	/**
	 * 析构函数，在销毁对象时被系统自动调用
	 */
	~TestClass()
	{
		cout << "析构函数被调用！" << endl;
	}
	
};


int main()
{
	TestClass *obj2 = new TestClass();
	delete((char *)obj2);
	return 0;
}