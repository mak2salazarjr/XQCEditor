#include <stdio.h>

/*
by 望尘11
*/
int fun()
{
	int a;
	__asm__(
		"mov %0,#9\n"
		"str %0, [fp, #-8]"
		:
		:"r"(a)
		:"r0"
		);
	return a;
}

int main(void)
{
	printf("%d\n",fun());
	return 0;
}
