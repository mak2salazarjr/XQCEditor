#ifndef TEXTVIEW_H_H
#define TEXTVIEW_H_H
extern int showText(const char* , float, float, int, int);
#endif