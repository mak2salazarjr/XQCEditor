/****
作者:复制哥
2016年9月1日
****/
#include "base.h"
#include <time.h>
#include "ui/ui.h"
#define IMG_COUNT 13
#define TEXT_SIZE 100
#define HORIGINAL_COUNT 8
#define VERTICAL_COUNT 8
#define DIFFICULT 8 //难度 值越小越难最小为0
#define PASS_SECOND 1000
//屏幕宽度
int mScreenW=0;
//屏幕高度
int mScreenH=0;
//屏幕像素密度
float mScreenD=1.0;
//
float mX=0;
float mY=0;
int mCount=0;
jobject mBitmap[IMG_COUNT];//水果图片
jobject boxImg = NULL;//选择框图片
jobject lzBitmap[4];//粒子图片
jobject titleBox[2];//按钮图片
jobject menuBitmap = NULL;//背景图片
jobject secondBitmap[10];//分数图片
jobject levelUp = NULL;
jobject level[10];//关数图片
jobject insectBitmap[4];//毛毛虫图片
PBUTTON Pmenu = NULL;
PBUTTON lz = NULL;
int gameData[VERTICAL_COUNT+3][HORIGINAL_COUNT];
int vertical[2];
int horizontal[2];
int tagId = 0;
char boxId = 0;
int difficult;//难度 值越小越难最小为0
int score = 0;//分数
int si = 0;
int passSecond = 0;
int passCount = 1;
int randn = 3;
float insectLeft;

//如果要使用LOGI,和LOGE请定义LOG_TAG这个宏
#define  LOG_TAG    "LOG_TAG"

void readImg();
void deleteImg();
void menu();
void textBackgroun();
void gameMenu();
void initialArray(int);
int getArrayXY(float, float, int* , int* , float* , float*, float* , float* );
int eliminateFruit(char);
void start_timer();
void showSecond();
void showSecondMs();
void passGame();
void passBackgroun();
void intervalTime();
void insectMovement();
void backMenu();
void reset();

//在程序启动时调用
void onCreate()
{
	srand(time(NULL));
	readImg();
	lz = createButton();
	Pmenu = createButton();
}

//触摸事件调用
void onTouchEvent(int action,float x,float y,int index,int count,float pointersX[],float pointersY[],int pointersId[])
{
	
	int type = 0;
	int p1 = buttonEvent(Pmenu, &type, x, y);
	static float pre_x = 0;
	static float pre_y = 0;
	static int pre_id = 0;
	if (ACTION_DOWN == action)
	{
	   setButtonBackground(Pmenu, p1, 0, titleBox[1]);
	   pre_y = y;
	   pre_x = x;
	   pre_id = p1;
	   	mX=x;
	    mY=y;
	  if (tagId == 4)
	  {
		  if (boxId == 0)
		  {
		     getArrayXY(x, y, &horizontal[0], &vertical[0], NULL, NULL, NULL, NULL);
		     boxId = 1;
		  }else if (boxId == 1)
		  {
		     getArrayXY(x, y, &horizontal[1], &vertical[1], NULL, NULL, NULL, NULL);
		     if (((horizontal[0]+1 == horizontal[1] || horizontal[0]-1 == horizontal[1]) && vertical[1] == vertical[0])  || ((vertical[0]+1 == vertical[1] || vertical[0]-1 == vertical[1]) && horizontal[0] == horizontal[1]))
		     {
		        int t = gameData[vertical[0]][horizontal[0]];
			    gameData[vertical[0]][horizontal[0]] = gameData[vertical[1]][horizontal[1]];
			    gameData[vertical[1]][horizontal[1]] = t;
			    if (eliminateFruit(1) == 0)
			    {
			       gameData[vertical[1]][horizontal[1]] = gameData[vertical[0]][horizontal[0]];
				   gameData[vertical[0]][horizontal[0]] = t;
			    }
		     }
		     else
		     {
		        boxId = 0;
			    return;
		     }
		     boxId = 0;
		  }
	   }
	}
	
	if (ACTION_UP == action)
	{
	    if (0 == tagId || 6 == tagId)
		{
		   setButtonBackground(Pmenu, pre_id, 0, titleBox[0]);
		   if (pre_x != x && pre_y != y)
		   {
			   PBUTTON p = seekId(Pmenu, pre_id);
			   if (p != NULL)
			   {
				   if (!((p->left <= x) && (p->right >= x) && (p->top <= y) && (p->bottom >= y)))
			       {
					   postInvalidate();
					   return;
			       }
		       }
		   }
		   
		   if (0 == p1)
	       {
			  randn = 3;
			  initialArray(randn);
			  clearButton(Pmenu);
			  difficult = DIFFICULT;
			  passSecond = PASS_SECOND;
			  passCount = 1;
			  insectLeft = mScreenW-80*2;
		      tagId = 4;
			  score = 0;
			  return;
		   }
		   if (1 == p1)
		   {
			   clearButton(Pmenu);
			   tagId = 1; 
			   FILE* fp;
               fp = fopen("/storage/emulated/0/sg.txt", "rb");
               if (fp != NULL)
               {
                  fread(&score, 1, sizeof(score), fp);
	              fclose(fp);
				  postInvalidate();
               }
		      
			  return;
		   }
		   if (2 == p1)
		   {
			 clearButton(Pmenu);
			 tagId = 2;
			 return;
		   }
		   if (3 == p1)
		   {
			 clearButton(Pmenu);
		     tagId = 3;
			 return;
		   }
		   if (4 == p1)
		   {
			  finish();
			  return;
		   }
		    if (5 == p1)
		   {
		      tagId = 4;
			  postInvalidate();
		   }
		   if (6 == p1)
		   {
			  reset();
		     clearButton(Pmenu);
	         menu();
	         tagId = 0;
	         postInvalidate();
		   }
		   return;
		}
		
	}
	
}

//只能在这里绘图
void onDraw(int left,int top,int right,int bottom )
{	
	drawColor(RGB(255, 255, 255));
	AndroidBitmapInfo bitmapInfo;
	getBitmapInfo(menuBitmap, &bitmapInfo);
	drawBitmap(menuBitmap, 0, 0, bitmapInfo.width, bitmapInfo.height, 0, 0, mScreenW, mScreenH);
	
	if (0 == tagId)
	{
	   traverseListDraw(Pmenu);
	}else if (1 == tagId)
	{
	   textBackgroun();
	   char buf[30];
	   sprintf(buf, "最高纪录%d分", score);
	   showText(buf, mScreenW/5, mScreenH/4+200, 50, RGB(255, 255, 255));
	   
	}else if (2 == tagId)
	{
	   textBackgroun();
	   showText("点击相邻两个图标即可交换，\n交换后如果有三个以上相同\n的图标排成一行或一列，\n即消去。", mScreenW/5, mScreenH/4+200, 50, RGB(255, 255, 255));
	}else if (3 == tagId)
	{
	   textBackgroun();
	   showText("作者:复制哥\n开发工具:快写代码\n欢迎加入望尘11开发者群,\n群号码:136898517", mScreenW/5, mScreenH/4+200, 50, RGB(255, 255, 255));
	}else if (4 == tagId)
	{
	   float selectBoxLeft = 0;
       float selectBoxTop = 0;
       float selectBoxRight = 0;
       float selectBoxBottom = 0;
	   gameMenu();
	   if (1 == boxId)
	   {
	      getArrayXY(mX, mY, NULL, NULL, &selectBoxLeft, &selectBoxTop, &selectBoxRight, &selectBoxBottom);	   
	      AndroidBitmapInfo bitmapInfo;
          getBitmapInfo(boxImg, &bitmapInfo);
          drawBitmap(boxImg, 0, 0, bitmapInfo.width, bitmapInfo.height, selectBoxLeft, selectBoxTop, selectBoxRight, selectBoxBottom);
	   }
	   showSecond();
	   showSecondMs();
	   passGame();
	   insectMovement();
	   traverseListDraw(lz);
     }
	 else if (tagId == 5)
	 {
	    passBackgroun();
	 }else if (tagId == 6)
	 {
	    traverseListDraw(Pmenu);
	 }
}


//屏幕大小发生变化时被调用 ，程序在启动后会调用一次
void onSizeChange(int w,int h,int oldw,int oldh,float density)
{
	mScreenW=w;
	mScreenH=h;
	mScreenD=density;
	if (Pmenu != NULL && Pmenu->Next == Pmenu)
	{
	   menu();
	}
}

//系统每1毫秒就会调用这个方法1次
void onLoopCall()
{
	start_timer();
	intervalTime();
}

//返回键被按下事件，如果 返回0则退出程序，
int onBackPressed()
{
	if (1 == tagId || 2 == tagId || 3 == tagId)
	{
	   clearButton(Pmenu);
	   menu();
	   tagId = 0;
	   postInvalidate();
	   return 1;
	}
	else if (tagId == 4)
	{
	   backMenu();
	   tagId = 6;
	   postInvalidate();
	   return 1;
	}else if (tagId == 6)
	{
	   clearButton(Pmenu);
	   tagId = 4;
	   postInvalidate();
	   return 1;
	}
	return 0;
}

//应用被暂停时调用，例如被后台运行
void onPause()
{
	showToastText("onPause",0);
}

//应用被恢复时调用，例如从后台运行转为前台运行
void onResume()
{
	showToastText("onResume",0);
}

//程序在被销毁时调用
void onDestroy()
{
    clearButton(lz);
	deleteButton(&lz);
	clearButton(Pmenu);
	deleteButton(&Pmenu);
	deleteImg();
	exit(0);
}
//读取图片
void readImg()
{
   int i;
   char buf[30];
   for (i = 0; i < IMG_COUNT; i++)
   {
	  sprintf(buf, "item_%d.png", i);
      mBitmap[i] = decodeBitmapFromAssets(buf);
   }
   for (i = 0; i < 10; i++)
   {
      sprintf(buf, "q%d.png", i);
	  secondBitmap[i] = decodeBitmapFromAssets(buf);
   }
   for (i = 0; i < 10; i++)
   {
      sprintf(buf, "level_n_%d.png", i);
	  level[i] = decodeBitmapFromAssets(buf);
   }
   for (i = 0; i < 4; i++)
   {
      sprintf(buf, "c%d.png", i+1);
	  insectBitmap[i] = decodeBitmapFromAssets(buf);
   }
   boxImg = decodeBitmapFromAssets("o0.png");
   menuBitmap = decodeBitmapFromAssets("menu.jpg");
   titleBox[0] = decodeBitmapFromAssets("button_0.png");
   titleBox[1] = decodeBitmapFromAssets("button_1.png");
   lzBitmap[0] = decodeBitmapFromAssets("boom00.png");
   lzBitmap[1] = decodeBitmapFromAssets("boom01.png");
   lzBitmap[2] = decodeBitmapFromAssets("boom02.png");
   lzBitmap[3] = decodeBitmapFromAssets("boom03.png");
   levelUp = decodeBitmapFromAssets("levelup00.png");
}
//销毁图片
void deleteImg()
{
   int i;
   for (i = 0; i < IMG_COUNT; i++)
   {
      deleteBitmap(mBitmap[i]);
	  mBitmap[i] = NULL;
   }
   for (i = 0; i < 10; i++)
   {
      deleteBitmap(secondBitmap[i]);
	  secondBitmap[i] = NULL;
   }
   for (i = 0; i < 10; i++)
   {
      deleteBitmap(level[i]);
	  level[i] = NULL;
   }
   for (i = 0; i < 4; i++)
   {
      deleteBitmap(insectBitmap[i]);
	  insectBitmap[i] = NULL;
   }
   deleteBitmap(boxImg);
   boxImg = NULL;
   deleteBitmap(menuBitmap);
   menuBitmap = NULL;
   deleteBitmap(titleBox[0]);
   titleBox[0] = NULL;
   deleteBitmap(titleBox[1]);
   titleBox[1] = NULL;
   deleteBitmap(lzBitmap[0]);
   lzBitmap[0] = NULL;
   deleteBitmap(lzBitmap[1]);
   lzBitmap[1] = NULL;
   deleteBitmap(lzBitmap[2]);
   lzBitmap[2] = NULL;
    deleteBitmap(lzBitmap[3]);
   lzBitmap[3] = NULL;
   deleteBitmap(levelUp);
   levelUp = NULL;
}
//主界面
void menu()
{
   char* title[] = 
   {
      "新的开始", 
	  "历史记录", 
	  "游戏帮助", 
	  "游戏关于", 
	  "退出游戏"
   };
   float left = mScreenW/5;
   float top = (float)mScreenH/4.0;
   float right = mScreenW-left;
   float bottom = ((float)mScreenH-top*2)/5;
   int i;
   for (i = 0; i < 5; i++)
   {
      addButton(Pmenu, 0, i, title[i], left, top, right, top+bottom, TEXT_SIZE, RGB(255, 255, 255), "0xffffff");
	  setButtonBackground(Pmenu, i, 0, titleBox[0]);
	  top += bottom;
   }
}
//游戏帮助背景
void textBackgroun()
{
	AndroidBitmapInfo bitmapInfo;
	getBitmapInfo(menuBitmap, &bitmapInfo);
    getBitmapInfo(titleBox[0], &bitmapInfo);
	float left = mScreenW/5;
    float top = (float)mScreenH/4.0;
    float right = mScreenW-left;
    float bottom = ((float)mScreenH-top*2);
	drawBitmap(titleBox[0], 0, 0, bitmapInfo.width, bitmapInfo.height, left, top, right, top+bottom);
}
//初始化数组
void initialArray(int r)
{
   int i;
   int j;
   int n;
   for (i = 0; i < VERTICAL_COUNT+3; i++)
   {
      for (j = 0; j < HORIGINAL_COUNT; j++)
	  {
	     n = rand()%r;
		 gameData[i][j] = n;
	  }
   }
}
void gameMenu()
{
   int i;
   int j;
   int t;
   int pre;
   AndroidBitmapInfo bitmapInfo;
   getBitmapInfo(mBitmap[0], &bitmapInfo);
   float left = 0;
   float top = (float)mScreenH/6.0;
   float right = (float)mScreenW/HORIGINAL_COUNT;
   float bottom = ((float)mScreenH - top*2)/VERTICAL_COUNT;   
   float preTop = 0;
   float preBottom = bottom;
   for (j = 0; j < HORIGINAL_COUNT; j++)
   {
	   for (i = 3; i < VERTICAL_COUNT+3; i++)
       {
		   pre = i-1;
		   for (t = i; t < VERTICAL_COUNT+3 && gameData[t][j] == -1; t++);
		   if (t != i)
		   {
		      for (; t >= 3; t--)
			  {
				 if (pre >= 0)
				 {
			        gameData[t-1][j] = gameData[pre--][j];
					if (pre == 2)
					{
					  preTop = (float)mScreenH/6.0-preBottom;
					}else if (pre == 1)
					{
					   preTop = (float)mScreenH/6.0-(preBottom*2);
					}
					else if (pre == 0)
					{
					   preTop = (float)mScreenH/6.0-(preBottom*3);
					}
					if (pre < 3 && pre >= 0)
					{
					   drawBitmap(mBitmap[gameData[t-1][j]], 0, 0, bitmapInfo.width, bitmapInfo.height, left, preTop, left+right, preTop+preBottom);
					}
					
				 }
				 else
				 {
				    gameData[t-1][j] = rand()%(IMG_COUNT-difficult);
				 }
			  }
		   }
	       drawBitmap(mBitmap[gameData[i][j]], 0, 0, bitmapInfo.width, bitmapInfo.height, left, top, left+right, top+bottom);
		   top += bottom;
       }
	  top = (float)mScreenH/6.0;	  
	  left += right;
   }
   for (i = 0; i < 3; i++)
   {
      for (j = 0; j < HORIGINAL_COUNT; j++)
	  {
	      gameData[i][j] = rand()%(IMG_COUNT-difficult);
	  }
   }
}


int getArrayXY(float x, float y, int* h, int* v, float* selectBoxLeft, float* selectBoxTop, float* selectBoxRight, float* selectBoxBottom)
{
   int i;
   int j;
   float left = 0;
   float top = (float)mScreenH/6.0;
   float right = (float)mScreenW/HORIGINAL_COUNT;
   float bottom = ((float)mScreenH - top*2)/VERTICAL_COUNT;
   for (i = 3; i < VERTICAL_COUNT+3; i++)
   {
      for (j = 0; j < HORIGINAL_COUNT; j++)
	  {
	     if ((x >= left && x <= left+right) && (y >= top && y <= top+bottom))
	     {
			if (h != NULL && v != NULL)
			{
		       *h = j;
			   *v = i;
			}
			if (selectBoxLeft != NULL && selectBoxRight != NULL && selectBoxTop != NULL && selectBoxBottom != NULL)
			{
			   *selectBoxLeft = left;
			   *selectBoxTop = top;
			   *selectBoxRight = left+right;
			   *selectBoxBottom = top+bottom;
			}
			return 1;
		 }
		 left += right;
	  }
	  left = 0;
	  top += bottom;
   }
   
   return 0;
}
int eliminateFruit(char n)
{
   int buf[VERTICAL_COUNT+3][HORIGINAL_COUNT] = {0};
   int i;
   int j;
   char flags = 0;
   for (i = 0; i < HORIGINAL_COUNT; i++)
   {
      for (j = 3; j < VERTICAL_COUNT+3; j++)
	  {
	     if (i <= HORIGINAL_COUNT-3 && gameData[j][i] == gameData[j][i+1] && gameData[j][i] == gameData[j][i+2])
		 {
		    buf[j][i] = -1;
			buf[j][i+1] = -1;
			buf[j][i+2] = -1;
		 }
		 if (j <= VERTICAL_COUNT && gameData[j][i] == gameData[j+1][i] && gameData[j][i] == gameData[j+2][i])
		 {
		    buf[j][i] = -1;
			buf[j+1][i] = -1;
			buf[j+2][i] = -1;
		 }
	  }
   }
   int id = 0;
   float left = 0;
   float top = (float)mScreenH/6.0;
   float right = (float)mScreenW/HORIGINAL_COUNT;
   float bottom = ((float)mScreenH - top*2)/VERTICAL_COUNT;
   for (i = 3; i < VERTICAL_COUNT+3; i++)
   {
      for (j = 0; j < HORIGINAL_COUNT; j++)
	  {
	     if (buf[i][j] == -1)
		 {
			if (0 == n)
			{
		       gameData[i][j] = buf[i][j];
			}
			else
			{
			   addButton(lz, 2, id, "10", left, top, left+right, top+bottom, 50, RGB(0, 255, 255), "0xffffff");
			   setButtonBackground(lz, id, 0, lzBitmap[0]);
			   id++;
			}
			flags = 1;
		 }
		 left += right;
	  }
	  left = 0;
	  top += bottom;
   }
   
   return flags > 0 ? 1: 0;
}
void start_timer()
{
   	static long long proTime=0;
	static int sm = 0;
	//每120毫秒执行一次
	if(currentTimeMillis()-proTime>120)
	{
		proTime=currentTimeMillis();	
		if (4 == tagId)
		{
	      if (lz->Next == lz)
		  {
		     if (eliminateFruit(1) == 1)
		     {
		        postInvalidate();
		     }
		  }
		  else
		  {
			 static int lzCount = 1;
		     if (lz->Next->Next->bitmap == lzBitmap[3])
			 {
			    clearButton(lz);
				lzCount = 1;
				eliminateFruit(0);
				postInvalidate();
			 }
			 else
			 {
				sm = 0;
			    PBUTTON p = lz->Next;
				while (p != lz)
				{
				   p->text_y -= 15;
				   p->left -= 5;
				   p->right += 5;
				   p->bitmap = lzBitmap[lzCount];
				   if (lzCount == 3)
				   {
				      score += 10;
					  sm += 10;
					  if (mScreenW-40*2 > insectLeft)
					  {
					     insectLeft += 10;
					  }
				   }
				   p = p->Next;
				}
				lzCount++;
				postInvalidate();
			 }
		  }
		}
		postInvalidate();
	}
    if (tagId == 4)
	{
	   if (sm > 0 || si > 0)
	   {
	         si++;
			 if (si == 10)
			 {
			    si = 0;
			 }
	         postInvalidateRect((float)mScreenW/1.5, (float)mScreenH/6.0-15*3, ((float)mScreenW/1.5)+14*2, ((float)mScreenH/6.0-15*3)+15*2);
		    sm -= 10;
	   }
	}
}
//显示分数
void showSecond()
{
   char buf[30];
   sprintf(buf, "%d", score);
   float left = (float)mScreenW/1.5;
   float top = (float)mScreenH/6.0-15*3;
   float right = 14*2;
   float bottom = 15*2;
   int len = strlen(buf);
   char data[2];
   int n;
   for (; len >= 1; len--)
   {
      data[0] = buf[len-1];
	  data[1] = '\0';
	  n = atoi(data);
	  drawBitmap(secondBitmap[n], 0, 0, 14, 15, left, top, left+right, top+bottom);
	  left -= 14*2;
   }
}
void showSecondMs()
{
   float left = (float)mScreenW/1.5;
   float top = (float)mScreenH/6.0-15*3;
   float right = 14*2;
   float bottom = 15*2;
   drawBitmap(secondBitmap[si], 0, 0, 14, 15, left, top, left+right, top+bottom);
   
}
//通关
void passGame()
{
   if (score >= passSecond)
   {
	  if (randn < 8)
	  {
	     randn++;
	  }
	  initialArray(randn);
      passSecond += PASS_SECOND;
	  insectLeft = mScreenW-80*2;
	  if (difficult > 0)
	  {
	     difficult--;
	  }
	  passCount++;
	  tagId = 5;
   }
}
void passBackgroun()
{
      AndroidBitmapInfo bitmapInfo;
	  getBitmapInfo(levelUp, &bitmapInfo);
	  float left = (float)mScreenW/4;
	  float top = (float)mScreenH/3;
	  float right = mScreenW-left;
	  float bottom = bitmapInfo.height;
	  drawBitmap(levelUp, 0, 0, bitmapInfo.width, bitmapInfo.height, left, top, right, top+bottom);
	  char buf[30];
	  sprintf(buf, "%d", passCount);
	  getBitmapInfo(level[0], &bitmapInfo);
	  int len = strlen(buf);
	  top = (float)mScreenH/2-bitmapInfo.height/3;
	  left = (float)mScreenW/2+(bitmapInfo.width*len)/2;
	  right = bitmapInfo.width*2;
	  bottom = bitmapInfo.height*3;
	  char data[2];
	  int n;
	  for (; len >= 1; len--)
	  {
	     data[0] = buf[len-1];
		 data[1] = '\0';
		 n = atoi(data);
		 drawBitmap(level[n], 0, 0, bitmapInfo.width, bitmapInfo.height, left, top, left+right, top+bottom);
		 left -= bitmapInfo.width*2;
	  }
	  
}
void intervalTime()
{
	static long long proTime=0;
    if(currentTimeMillis()-proTime>1000)
	{
		proTime=currentTimeMillis();	
		if (tagId == 4)
		{
		   insectLeft -= 10;
		}
		else
		if (tagId == 5)
		{
		   static int passTime = 0;
		   if (passTime >= 2)
		   {
		      passTime = 0;
			  tagId = 4;
		   }
		   passTime++;
		}
    }
}
//毛毛虫运动
void insectMovement()
{
   static int sn = 0;
   if (sn >= 4)
   {
      sn = 0;
   }
   AndroidBitmapInfo bitmapInfo;
   getBitmapInfo(insectBitmap[0], &bitmapInfo);
   drawBitmap(insectBitmap[sn], 0, 0, bitmapInfo.width, bitmapInfo.height, insectLeft, mScreenH-mScreenH/16, insectLeft+bitmapInfo.width*2, mScreenH-mScreenH/16+(bitmapInfo.height*2));   
   if (insectLeft <= 0)
   {
       clearButton(Pmenu);
	   menu();
	   reset();
	   tagId = 0;
	   postInvalidate();
   }
   sn++;
}
void backMenu()
{
   clearButton(Pmenu);
   float left = (float)mScreenW/5;
   float top = (float)mScreenH/3;
   float right = mScreenW-left;
   float bottom = ((float)mScreenH-top*2)/2;
   addButton(Pmenu, 0, 5, "继续游戏", left, top, right, top+bottom, TEXT_SIZE, RGB(255, 255, 255), "0xffffff");
   setButtonBackground(Pmenu, 5, 0, titleBox[0]);
   top += bottom;
   addButton(Pmenu, 0, 6, "返回主菜单", left, top, right, top+bottom, TEXT_SIZE, RGB(255, 255, 255), "0xffffff");
   setButtonBackground(Pmenu, 6, 0, titleBox[0]);
}
//写入分数
void reset()
{
   int recordScore = -1;
   FILE* fp;
   fp = fopen("/storage/emulated/0/sg.txt", "rb");
   if (fp != NULL)
   {
      fread(&recordScore, 1, sizeof(recordScore), fp);
	  fclose(fp);
   }
   if (recordScore < score)
   {
	   
      fp = fopen("/storage/emulated/0/sg.txt", "wb");
	  if (fp != NULL)
	  {
         fwrite(&score, 1, sizeof(score), fp);
         fclose(fp);
	  }
	  else
	  {
	     fp = fopen("/storage/sdcard1/sg.txt", "wb");
		 if (fp != NULL)
		 {
		    fwrite(&score, 1, sizeof(score), fp);
            fclose(fp);
		 }
	  }
   }
   
}