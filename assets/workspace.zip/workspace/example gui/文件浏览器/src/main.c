#include "base.h"
#include "ui/fileBrowser/fileBrowser.h"
//屏幕宽度
int mScreenW=0;
//屏幕高度
int mScreenH=0;
//屏幕像素密度
float mScreenD=1.0;
//
float mX=0;
float mY=0;
float *mPXs=NULL;
float *mPYs=NULL;
int mCount=0;
jobject mBitmap=NULL;
jobject mMediaPlayer=NULL;

//如果要使用LOGI,和LOGE请定义LOG_TAG这个宏
#define  LOG_TAG    "LOG_TAG"

//在程序启动时调用
void onCreate()
{
	mBitmap=decodeBitmapFromAssets("folder.png");
}

//触摸事件调用
void onTouchEvent(int action,float x,float y,int index,int count,float pointersX[],float pointersY[],int pointersId[])
{
	LOGI("onTouchEvent:action:%d,x:%f,y:%f",action,x,y);
	mX=x;
	mY=y;
	mPXs=pointersX;
	mPYs=pointersY;
	mCount=count;
	int a = fileBrowserEvent(action, x, y);//文件浏览器按键事件
	if (a == 1)
	{
	   showToastText(getFilePath(), 1);
	}else if (a == 2)
	{
	   showToastText("返回键被点击", 1);
	}
	invalidate();
}

//只能在这里绘图
void onDraw(int left,int top,int right,int bottom )
{
	showFileBrowser();//显示文件浏览器列表
}


//屏幕大小发生变化时被调用 ，程序在启动后会调用一次
void onSizeChange(int w,int h,int oldw,int oldh,float density)
{
	mScreenW=w;
	mScreenH=h;
	mScreenD=density;
	initialFileBrowser(mScreenW, mScreenH);//初始化文件浏览器
	fileBrowserPath("/sdcard");//文件路径
}

//系统每1毫秒就会调用这个方法1次
void onLoopCall()
{
	browserMoveSpeed();//文件浏览器长按快速滚动
}

//返回键被按下事件，如果 返回0则退出程序，
int onBackPressed()
{
	return 0;
}

//应用被暂停时调用，例如被后台运行
void onPause()
{
	showToastText("onPause",0);
}

//应用被恢复时调用，例如从后台运行转为前台运行
void onResume()
{
	showToastText("onResume",0);
}

//程序在被销毁时调用
void onDestroy()
{
	deleteBitmap(mBitmap);
    destroyFileBrowser();//销毁文件浏览器
	exit(0);
}
