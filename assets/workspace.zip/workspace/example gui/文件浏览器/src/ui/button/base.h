#ifndef BASE_H
#define BASE_H

#include <jni.h>
#include <stdlib.h>
#include <stdio.h>
#include <android/bitmap.h>

#include <android/log.h>

//#define  LOG_TAG    "LOG_TAG"
#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)


enum {
	ACTION_MASK = 255,
	ACTION_DOWN = 0,	//按下事件
	ACTION_UP = 1,		//抬起事件
	ACTION_MOVE = 2,	//移动事件
	ACTION_CANCEL = 3,
	ACTION_OUTSIDE = 4,
	ACTION_POINTER_DOWN = 5,
	ACTION_POINTER_UP = 6,
	ACTION_POINTER_INDEX_MASK = 65280,
	ACTION_POINTER_INDEX_SHIFT = 8,
	ACTION_POINTER_1_DOWN = 5,
	ACTION_POINTER_2_DOWN = 261,
	ACTION_POINTER_3_DOWN = 517,
	ACTION_POINTER_1_UP = 6,
	ACTION_POINTER_2_UP = 262,
	ACTION_POINTER_3_UP = 518,
	ACTION_POINTER_ID_MASK = 65280,
	ACTION_POINTER_ID_SHIFT = 8,
};

/**
 * 通过    透明(a) 红(r) 绿(g) 蓝(b)
 * 来构造颜色
 */
#define ARGB(a,r,g,b) ( ((a&0xff)<<24) | ((r&0xff)<<16) | ((g&0xff)<<8) | (b&0xff) )

/**
 * 通过    红(r) 绿(g) 蓝(b)
 * 来构造颜色
 */
#define RGB(r,g,b) ARGB(0xff,r,g,b)

/**
 * 用color这个颜色清除屏幕
 */
void drawColor(int color);

/**
 * 设置画笔颜色:color
 * 设置了之后，以后所有绘图操作都是这个颜色
 */
void setColor(int color);

/**
 * 设置绘图的字体大小为:size
 */
void setTextSize(float size);

/**
 * 画线
 * startX:起点的横坐标
 * startY:起点的纵坐标
 * stopX:终点的横坐标
 * stopY:终点的纵坐标
 */
void drawLine( float startX,float startY,float stopX,float stopY);

/**
 * 画文字
 * text:文本内容
 * x:起点的横坐标
 * x:起点的纵坐标
 */
void drawText(const char * text,float x,float y);

/**
 * 不可在onDraw里面调用。
 * 重新绘图
 */
void invalidate();

/**
 * 通知系统需要重新绘图
 */
void postInvalidate();

/**
 * 不可在onDraw里面调用。
 * left,top,right,bottom:绘图区域
 * 重新绘图
 */
void invalidateRect(int left,int top,int right,int bottom);

/**
 * left,top,right,bottom:绘图区域
 * 通知系统需要重新绘图
 */
void postInvalidateRect(int left,int top,int right,int bottom);

/**
 * 画矩形
 */
void drawRect(float left, float top, float right, float bottom);


/**
 * 画圆角矩形
 */
void drawRoundRect(float left, float top, float right, float bottom,float rx,float ry);

/**
 * 从assets中解码图片
 * 如果解码失败返回NULL
 * 返回值需要通过deleteBitmap释放
 */
jobject decodeBitmapFromAssets(jstring name);

/**
 * 从文件中解码图片
 * 如果解码失败返回NULL
 * 返回值需要通过deleteBitmap释放
 */
jobject decodeBitmapFromFile(jstring path);

/**
 * 创建一个位图
 * 返回值需要通过deleteBitmap释放
 */
jobject createBitmap(int width,int height);

/**
 * 释放位图
 */
void deleteBitmap(jobject bitmap);

/**
 * 获取位图的宽度高度等信息
 */
void getBitmapInfo(jobject bitmap,AndroidBitmapInfo *bitmapInfo);

/**
 * 画位图
 * bitmap:需要画的位图
 * fromLeft,fromTop,fromRight,fromBottom : 从位图的哪一部分开始画
 * toLeft,toTop,toRight,toBottom : 画到屏幕的哪一部分
 */
void drawBitmap(jobject bitmap,int fromLeft,int fromTop,int fromRight,int fromBottom,float toLeft,float toTop,float toRight,float toBottom);

/**
 * 测量文本宽度
 */
float measureTextEx(jstring string,int start,int end);

/**
 * 测量文本宽度
 */
float measureText(jstring string);

/**
 * 结束当前程序
*/
void finish();

/**
 * 用于编辑框回调的指针接口
 * string : 文本内容，需要通过deleteJString释放。
 * cur : 当前光标位置
 */
typedef void (*EditTextCallback) ( jstring string,int cur );

/**
 * 请求编辑文字
 * string : 文本内容
 * cur : 当前光标位置
 * onSure : 按下确定键的回调
 * onCancle : 按下取消键的回调
 */
int requestEditText(jstring title,jstring string,int cur,EditTextCallback onSure,EditTextCallback onCancel);

/**
 * 显示一个提示
 * string : 要显示的文本
 * time: 0:短暂  	1:长
 */
void showToast(jstring string,int time);

void showToastText(const char *text,int time);

/**
 * 创建java字符串
 * 返回值需要通过deleteJString释放
 */
jstring createJString(const char* text);

/**
 * 删除java字符串
 */
void deleteJString(jstring string);

/**
 * 得到java字符串长度
 */
int lengthOfJString(jstring string);

/**
 * 当前时间
 * 从1970年1月1号到现在的毫秒数
 */
long long currentTimeMillis();

/**
 * 获取系统启动时间,单位纳秒
 */
long long nanoTime();

/**
 * 从Assets中读取文件的全部内容。
 * 通过outLength输出长度，如果outLength返回-1那么读取失败。
 * 返回的内存需要使用free释放，如果返回NULL那么读取失败。
 */
void *readAllFromAssets(const char *name,int *outLength);

#endif



