#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include "../base.h"
#include "fileBrowser.h"
#include "../button/Button.h"

static PFB pBrowser = NULL;
static PBUTTON Pbutton = NULL;

static void clearFileBrowser();
static int operationFileBrowser(int p1);
static void readBrowserIcon();
static void addFileList(const char* filenameName, jobject bitmap);
static int browserListEmpty();
static void seekBackLocation(int m, int c);

void initialFileBrowser(int w, int h)
{
   if (pBrowser != NULL)
   {
      destroyFileBrowser();
   }
   pBrowser = (PFB)malloc(sizeof(FB));
   pBrowser->phead = (PLNODE)malloc(sizeof(LNODE));
   pBrowser->phead->Next = pBrowser->phead;
   pBrowser->phead->Prior = pBrowser->phead;
   pBrowser->currentNode = NULL;
   pBrowser->mScreenW = w;
   pBrowser->mScreenH = h;
   pBrowser->textSize = h/40;
   pBrowser->fromTop = (float)(pBrowser->mScreenH)/15.0;
   pBrowser->fromBottom = (float)(pBrowser->mScreenH)/1.3-pBrowser->fromTop;
   pBrowser->number = 0;
   pBrowser->count = 0;
   pBrowser->filePathInfo = NULL;
   pBrowser->stackN = 0;
   pBrowser->pCurrent = 0;
   pBrowser->timerTime = KEY_RESPONSE_TIME;
   pBrowser->intervalTime = 0;
   pBrowser->timerTag = 0;
   readBrowserIcon();
   Pbutton = createButton();
   float left = 0;
   float right = w/4;
   addButton(Pbutton, 10, 0, "..", 0, 0, w, (float)(pBrowser->mScreenH)/15.0+(float)(pBrowser->textSize)/10, pBrowser->textSize, RGB(0, 0, 0), "0x00ffff");
   setButtonText(Pbutton, 0, "", RGB(0, 0, 0), pBrowser->textSize, "left");
   int i;
   char* title[] = 
   {
      "上", 
	  "确定", 
	  "下", 
	  "退出"
   };
   for (i = 1; i < 5; i++)
   {
      addButton(Pbutton, 10, i, title[i-1], left, h/1.1, left+right, h, pBrowser->textSize, RGB(0, 0, 0), "0x00ffff");
	  left += right+2;
   }
   
}
static void readBrowserIcon()
{
   pBrowser->icon[0] = decodeBitmapFromAssets("folder.png");
   pBrowser->icon[1] = decodeBitmapFromAssets("file_empty.png");
}
static void addFileList(const char* filenameName, jobject bitmap)
{
   PLNODE newNode = (PLNODE)malloc(sizeof(LNODE));
   int len = strlen(filenameName);
   newNode->name = (char* )malloc(len+1);
   strcpy(newNode->name, filenameName);
   newNode->bitmap = bitmap;
   newNode->bottom = ((float)(pBrowser->mScreenH)/1.3-(float)(pBrowser->mScreenH)/15.0)/9.0;
   
   struct stat st;
   stat(filenameName, &st);
   if (S_ISDIR(st.st_mode))
   {
	  newNode->fileTag = 0;
      newNode->Next = pBrowser->phead->Next;
	  newNode->Prior = pBrowser->phead;
	  pBrowser->phead->Next->Prior = newNode;
	  pBrowser->phead->Next = newNode;
   }else if (S_ISREG(st.st_mode))
   {
	  newNode->fileTag = 1;
      newNode->Next = pBrowser->phead;
      newNode->Prior = pBrowser->phead->Prior;
      pBrowser->phead->Prior->Next = newNode;
      pBrowser->phead->Prior = newNode;
   }
   else
   {
      free(newNode->name);
	  free(newNode);
   }
      
}
void showFileBrowser()
{
   if (pBrowser != NULL)
   {
	  if (traverseListDraw(Pbutton) == 1)
	  {
	     char buf[80];
	     sprintf(buf, "%d/%d", pBrowser->count, pBrowser->number);
	     jobject jstr = createJString(buf);
	     float width = measureText(jstr);
	     drawText(buf, (float)(pBrowser->mScreenW)-width, pBrowser->fromTop);
	     deleteJString(jstr);
	  }
	  if (browserListEmpty() == 0)
	  {
         PLNODE p = pBrowser->currentNode;
         AndroidBitmapInfo bitmapInfo = {0};
         setTextSize(pBrowser->textSize);
	     float top = pBrowser->fromTop;
	     float bottom = pBrowser->fromBottom/9.0;
	     int i;
	     char* str = NULL;
         for (i = 0; p != pBrowser->phead && i < 10; i++)
         {
		    p->top = top;
	        getBitmapInfo(p->bitmap, &bitmapInfo);
	        setColor(RGB(0, 0, 0));
		    if (p->bitmap != NULL)
		    {
               drawBitmap(p->bitmap, 0, 0, bitmapInfo.width, bitmapInfo.height, 0, p->top, (float)(pBrowser->mScreenW)/8.0, p->top+p->bottom);
		    }
	        drawLine(0, p->top+p->bottom, pBrowser->mScreenW, p->top+p->bottom);
		    str = strrchr(p->name, '/');
		    if (str != NULL)
		    {
	           drawText(str+1, (float)(pBrowser->mScreenW)/8.0, p->top+p->bottom/2+pBrowser->textSize/2);
		    }
		    top += bottom;
	        p = p->Next;
         }
	
         setColor(ARGB(128, 128, 128, 128));
         drawRect(0, pBrowser->moveNode->top, pBrowser->mScreenW, pBrowser->moveNode->top+pBrowser->moveNode->bottom);
		 
      }
   }
}

static int operationFileBrowser(int p1)
{
   if (1 == p1)
   {
      if (pBrowser->moveNode->Prior != pBrowser->phead)
	  {
		 if (pBrowser->moveNode->top <= pBrowser->fromTop)
		 {
		    pBrowser->currentNode = pBrowser->currentNode->Prior;
			pBrowser->pCurrent--;
		 }
	     pBrowser->moveNode = pBrowser->moveNode->Prior;
		 pBrowser->count--;
	  }
   }else if (2 == p1)
   {
      if (pBrowser->moveNode->fileTag == 0)
	  {
		 if (pBrowser->stackN < STATIC_STACK_SIZE)
		 {
		    pBrowser->moveStack[pBrowser->stackN] = pBrowser->count;
			pBrowser->currentStack[pBrowser->stackN] = pBrowser->pCurrent;
			pBrowser->stackN++;
		 }
		 fileBrowserPath(pBrowser->moveNode->name);
		 setButtonText(Pbutton, 4, "上一级", RGB(0, 0, 0), pBrowser->textSize, "center");
	  }else if (pBrowser->moveNode->fileTag == 1)
	  {
		  pBrowser->filePathInfo = (char* )malloc(strlen(pBrowser->moveNode->name)+1);
		  strcpy(pBrowser->filePathInfo, pBrowser->moveNode->name);
		  clearFileBrowser();
		  clearButton(Pbutton);
	      return 1;
	  }
   }else if (3 == p1)
   {
      if (pBrowser->moveNode->Next != pBrowser->phead)
	  {
		 if (pBrowser->moveNode->top >= pBrowser->fromBottom)
		 {
		    pBrowser->currentNode = pBrowser->currentNode->Next;
			pBrowser->pCurrent++;
		 }
	     pBrowser->moveNode = pBrowser->moveNode->Next;		 
		 pBrowser->count++;
	  }
   }
   
   return 0;
}
int fileBrowserPath(const char* fname)
{
	if (pBrowser == NULL || fname == NULL || *fname == '\0')
	{
	   return 0;
	}
	char* name = (char* )malloc(strlen(fname)+1);
	strcpy(name, fname);
	clearFileBrowser();
    DIR * dp;
	struct dirent *filename;
    struct stat st;
	dp = opendir(name);
	if (!dp)
	{
		fprintf(stderr,"open directory error\n");
		return 0;
	}
	setButtonText(Pbutton, 0, name, RGB(0, 0, 0), pBrowser->textSize, "left");
	pBrowser->number = 0;
	int i = 0;
	char bname[1000];
	while ((filename=readdir(dp)))
	{
		
		if (strcmp(filename->d_name, ".") != 0 && strcmp(filename->d_name, "..") != 0)
		{
		   sprintf(bname, "%s/%s", name, filename->d_name);
		   stat(bname, &st);
		   if (S_ISDIR(st.st_mode))
		   {
		      i = 0;
		   }else if (S_ISREG(st.st_mode))
		   {
		      i = 1;
		   }
		   addFileList(bname, pBrowser->icon[i]);
		   pBrowser->number++;
		}
		//printf("filename:%-10s\td_info:%ld\t d_reclen:%us\n",
		//filename->d_name,filename->d_ino,filename->d_reclen);
	}
	if (pBrowser->number > 0)
	{
	   pBrowser->currentNode = pBrowser->phead->Next;
	   pBrowser->moveNode = pBrowser->phead->Next;
	   pBrowser->count = 1;
	   pBrowser->pCurrent = 1;
	}
	closedir(dp);
	free(name);
	name = NULL;
	
	return 1;
}
static int browserListEmpty()
{
   if (pBrowser->phead->Next == pBrowser->phead)
   {
      return 1;
   }
   
   return 0;
}
char* getFilePath()
{
   if (pBrowser != NULL)
   {
      return pBrowser->filePathInfo;
   }
   else
   {
      return NULL;
   }
}
static void seekBackLocation(int m, int c)
{
   if (browserListEmpty() == 0)
   {
	  PLNODE p = pBrowser->phead->Next;
      int i;
	  for (i = 0; p != pBrowser->phead && i < m; i++)
	  {
	     if (i == c-1)
		 {
			pBrowser->pCurrent = c;
		    pBrowser->currentNode = p;
		 }
		 if (i == m-1)
		 {
			pBrowser->count = m;
		    pBrowser->moveNode = p;
		 }
		 p = p->Next;
	  }
   }
}
void browserMoveSpeed()
{
   if (pBrowser != NULL && browserListEmpty() == 0 && pBrowser->timerTag > 0)
   {
      static long long BproTime = 0;
	  if(currentTimeMillis()-BproTime>pBrowser->timerTime)
	  {
		 BproTime=currentTimeMillis();	
		 if (pBrowser->intervalTime > INTERVAL_TIME)
		 {
			operationFileBrowser(pBrowser->timerTag);
			pBrowser->timerTime = TIMER_SPEED;		    	
	    	postInvalidate();
		 }
		 else
		 {
		    pBrowser->intervalTime++;
		 }
		 
	  }
   }
}
int fileBrowserEvent(int action, float x, float y)
{
   if (pBrowser != NULL)
   {
	  int type = 0;
      int p1 = buttonEvent(Pbutton, &type, x, y);
	  if (ACTION_UP == action)
	  {
	     pBrowser->timerTag = 0;	     
	     pBrowser->intervalTime = 0;	  
	     if (10 == type && pBrowser->timerTime != TIMER_SPEED)
	     {
	        int info = 0;
		    if (browserListEmpty() == 0)
		    {
		        info = operationFileBrowser(p1);
		    }
		    if (4 == p1)
            {
	           char* str = strrchr(Pbutton->Next->text, '/');
	           if (str != NULL)
	           {
	               *str = 0;
		           if (fileBrowserPath(Pbutton->Next->text) == 0)
				   {
					   clearFileBrowser();
					   clearButton(Pbutton);
					   info = 2;
		           }
				   else
				   {
				      if (pBrowser->stackN > 0)
				      {
					     pBrowser->stackN--;
				         seekBackLocation(pBrowser->moveStack[pBrowser->stackN], pBrowser->currentStack[pBrowser->stackN]);
				      }
					  if (pBrowser->stackN == 0)
					  {
					     setButtonText(Pbutton, 4, "退出", RGB(0, 0, 0), pBrowser->textSize, "center");
					  }
				   }
	            }             	             
		     }
			 postInvalidate();
		     return info;
	      }		 
		  pBrowser->timerTime = KEY_RESPONSE_TIME;
	   }
	   
	   if (ACTION_DOWN == action)
	   {
		  
		   if (p1 == 1)
		   {
		      pBrowser->timerTag = p1;
		   }else if (p1 == 3)
		   {
		      pBrowser->timerTag = p1;
		   }
       }
   }
   return 0;
}
static void clearFileBrowser()
{
   PLNODE p = pBrowser->phead->Next;
   PLNODE q = NULL;
   while (p != pBrowser->phead)
   {
      q = p->Next;
	  free(p->name);
	  p->name = NULL;
	  free(p);
	  p = q;
   }
   pBrowser->phead->Next = pBrowser->phead;
   pBrowser->phead->Prior = pBrowser->phead;
   pBrowser->currentNode = NULL;
   pBrowser->moveNode = NULL;
   pBrowser->number = 0;
   pBrowser->count = 0;
   pBrowser->pCurrent = 0;
}
void destroyFileBrowser()
{
   if (pBrowser != NULL)
   {
      clearFileBrowser();
      free(pBrowser->phead);
      int i;
      for (i = 0; i < BROWSER_ICON_COUNT; i++)
      {
         deleteBitmap(pBrowser->icon[i]);
	     pBrowser->icon[i] = NULL;
      }
	  if (pBrowser->filePathInfo != NULL)
      {
		  free(pBrowser->filePathInfo);
	      pBrowser->filePathInfo = NULL;
	  }
      free(pBrowser);
      pBrowser = NULL;
      clearButton(Pbutton);
      destroyButton(&Pbutton);
   }
}