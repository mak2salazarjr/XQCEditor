#ifndef FILEBROWSER_H_
#define FILEBROWSER_H_
#include "../base.h"
#define BROWSER_ICON_COUNT 2
#define STATIC_STACK_SIZE 150
#define INTERVAL_TIME 1
#define TIMER_SPEED 30
#define KEY_RESPONSE_TIME 300
typedef struct lnode
{
   char* name;
   float left;
   float top;
   float right;
   float bottom;
   jobject bitmap;
   struct lnode* Prior;
   struct lnode* Next;
   char fileTag;
}LNODE, *PLNODE;
typedef struct fb
{
   int textSize;
   int mScreenW;
   int mScreenH;
   int number;
   int count;
   int pCurrent;
   float timerTime;
   float intervalTime;
   float fromTop;
   float fromBottom;
   char* filePathInfo;
   jobject icon[BROWSER_ICON_COUNT];
   int moveStack[STATIC_STACK_SIZE];
   int currentStack[STATIC_STACK_SIZE];
   int stackN;
   PLNODE moveNode;
   PLNODE currentNode;
   PLNODE phead;
   char timerTag;
}FB, *PFB;

//初始化文件浏览器，传屏幕宽 高
extern void initialFileBrowser(int w, int h);

//文件浏览器路径
extern int fileBrowserPath(const char* name);

//显示列表，放在noDraw函数里即可
extern void showFileBrowser();

//放在onLoopCall函数里即可
extern void browserMoveSpeed();

//获取文件浏览器路径，成功返回路径，返回的信息由destroyFileBrowser函数释放
extern char* getFilePath();

//文件浏览器按键事件，点击文件确定返回1，取消返回2，放在onTouchEvent函数即可
extern int fileBrowserEvent(int action, float x, float y);

//销毁文件浏览器
extern void destroyFileBrowser();

#endif