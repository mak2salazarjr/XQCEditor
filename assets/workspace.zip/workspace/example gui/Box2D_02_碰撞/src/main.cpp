#include "base.h"
#include <math.h>
#include "Box2D/Box2D.h"

//如果要使用LOGI,和LOGE请定义LOG_TAG这个宏
#define  LOG_TAG    "LOG_TAG"

//弧度转角度
float r2d(float r)
{
	return 180/M_PI*r;
}

//角度转弧度
float d2r(float d)
{
	return M_PI/180*d;
}

class MyWorld {
	b2World *world ;
	float scaleX;
	float scaleY;
public:
	MyWorld ()
	{
		scaleX = 4.0f;
		scaleY = 4.0f;
		//初始化重力向量
		b2Vec2 gravity;
		gravity.Set(0.0f,-10.0f);
		//使用刚刚定义的重力创建一个物理世界
		world = new b2World(gravity);
		
		
		//定义背景实体
		b2Body *groundBody;
		b2BodyDef groundBodyDef;
		//设置实体的位置
		groundBodyDef.position.Set(2.0f, 2.0f);
		//通过刚刚的实体定义来创建实体
		groundBody = world->CreateBody(&groundBodyDef);

		//定义实体多边形模型，物理碰撞都是通过这些定点计算得来的
		b2PolygonShape groundBox;
		//将这个多边形设置为像个箱子一样（既长方体）,1000是长方体的宽的一半，10为长方体的高的一半
		groundBox.SetAsBox(1000.0f,10.0f);
		//通过多边形的定义创建实体的定点,0.0f是它的密度。
		groundBody->CreateFixture(&groundBox,0.2f);

		//定义一个动态的实体
		b2Body* body;
		b2BodyDef bodyDef;
		//设置实体类型为动态实体（b2_dynamicBody），默认为静态实体（b2_staticBody）,静态实体被碰撞时，会静止不动，相当于质量无穷大,刚刚定义的groundBody就是静态实体
		bodyDef.type = b2_dynamicBody;
		//设置实体的初始位置
		bodyDef.position.Set(0.0f, 400.0f);
		//设置实体的角度
		bodyDef.angle = 10.0f;
		//设置实体的线速度
		bodyDef.linearVelocity.Set(10.0f,0.0f);
		//通过上面的定义创建这个实体
		body = world->CreateBody(&bodyDef);

		//为上面的动态实体创建多边形模型，（这样就能让实体参与碰撞了）。
		b2PolygonShape dynamicBox;
		//设置宽高
		dynamicBox.SetAsBox(10.0f, 10.0f);

		//为了设置其详细的物理属性定义fixtureDef
		b2FixtureDef fixtureDef;
		//让详细物理属性的多边形模型指向刚刚定义的多边形模型
		fixtureDef.shape = &dynamicBox;
		//设置其密度，密度不为0！
		fixtureDef.density = 10.0f;
		//重写其默认的摩擦力
		fixtureDef.friction = 0.3f;
		//设置实体的弹性
		fixtureDef.restitution = 0.6f;
		//添加多边形模型
		body->CreateFixture(&fixtureDef);

	}
	
	void step()
	{
		float32 timeStep = 1.0f / 20.0f; //default :1.0f / 60.0f
		int32 velocityIterations = 6; //default :6
		int32 positionIterations = 6; //default :2
		// Instruct the world to perform a single step of simulation.
		// It is generally best to keep the time step and iterations fixed.
		world->Step(timeStep, velocityIterations, positionIterations);
	}
	
	void render()
	{
		canvasScale(scaleX,scaleY,0,0);
		
		//得到实体列表
		b2Body *tbody = this->world->GetBodyList();

		while(tbody!=NULL)
		{//遍历所有实体
			//得到实体位置
			b2Vec2 position = tbody->GetPosition();
			//保存画布状态
			canvasSave();
			//平移画布
			canvasTranslate(position.x,position.y);
			//旋转画布，由于box2d使用的是弧度，而安卓使用的是角度，因此使用r2d转换为角度
			canvasRotate( r2d(tbody->GetAngle()),0,0);

			//得到物理属性列表
			b2Fixture *fixture = tbody->GetFixtureList();
			while(fixture!=NULL)
			{//遍历物理属性列表，(这里我们只有用到了一个物理属性)
				//(因为我们设置的是b2PolygonShape*类型，因此可以强转)
				b2PolygonShape *shape = (b2PolygonShape*)(fixture->GetShape());
				//得到模型的顶点总数
				int count = shape->GetVertexCount();
				for(int i=0;i<count;i++)
				{//遍历所有顶点,并将其连接成线段
					b2Vec2 pointStart = shape->GetVertex(i);
					b2Vec2 pointEnd;
					if(i+1==count)
						pointEnd = shape->GetVertex( 0 );
					else
						pointEnd = shape->GetVertex( i+1 );
					drawLine(pointStart.x,pointStart.y,pointEnd.x,pointEnd.y);
				}
				fixture = fixture->GetNext();
			}
			canvasRestore();

			tbody = tbody->GetNext();
		}
	}

	void addTestBox(float x,float y)
	{
		x/=scaleX;
		y/=scaleY;
		//定义一个动态的实体
		b2Body* body;
		b2BodyDef bodyDef;
		//设置实体类型为动态实体（b2_dynamicBody），默认为静态实体（b2_staticBody）,静态实体被碰撞时，会静止不动，相当于质量无穷大,刚刚定义的groundBody就是静态实体
		bodyDef.type = b2_dynamicBody;
		//设置实体的初始位置
		bodyDef.position.Set(x,y);
		//设置实体的角度
		bodyDef.angle = 0.0f;
		//设置实体的线速度
		bodyDef.linearVelocity.Set(0.0f,0.0f);
		//通过上面的定义创建这个实体
		body = world->CreateBody(&bodyDef);

		//为上面的动态实体创建多边形模型，（这样就能让实体参与碰撞了）。
		b2PolygonShape dynamicBox;
		//设置宽高
		dynamicBox.SetAsBox(10.0f, 10.0f);

		//为了设置其详细的物理属性定义fixtureDef
		b2FixtureDef fixtureDef;
		//让详细物理属性的多边形模型指向刚刚定义的多边形模型
		fixtureDef.shape = &dynamicBox;
		//设置其密度，密度不为0！
		fixtureDef.density = 10.0f;
		//重写其默认的摩擦力
		fixtureDef.friction = 0.3f;
		//设置实体的弹性
		fixtureDef.restitution = 0.6f;
		//添加多边形模型
		body->CreateFixture(&fixtureDef);
	}

	~MyWorld()
	{
	}
};

MyWorld *mWorld;

extern "C" {

//在程序启动时调用
void onCreate()
{
	mWorld = new MyWorld();
}

//触摸事件调用
void onTouchEvent(int action,float x,float y,int index,int count,float pointersX[],float pointersY[],int pointersId[])
{
	//if(action == ACTION_DOWN)
		mWorld->addTestBox(x,y);
}

//只能在这里绘图
void onDraw(int left,int top,int right,int bottom )
{
	drawText("hello world!",100,100);
	mWorld->render();
}

//屏幕大小发生变化时被调用 ，程序在启动后会调用一次
void onSizeChange(int w,int h,int oldw,int oldh,float density)
{
}
long long preTime = 0;
//系统每1毫秒就会调用这个方法1次
void onLoopCall()
{
	long long time = currentTimeMillis();
	if(time-preTime>1000/30)
	{
		mWorld->step();
		postInvalidate();
		preTime = time;
	}
}

//返回键被按下事件，如果 返回0则退出程序，
int onBackPressed()
{
	return 0;
}

//应用被暂停时调用，例如被后台运行
void onPause()
{
}

//应用被恢复时调用，例如从后台运行转为前台运行
void onResume()
{
}

//程序在被销毁时调用
void onDestroy()
{
}

} // end extern C
