#include "base.h"
#include "Nes/Console.h"
#include "Nes/Image.h"
#include <pthread.h>

bool mButton[8] = {false,false,false,false
		,false,false,false,false};
		
int  keyMapper[6][20] = {
	{-1, 4, 4, 4, 4,  -1,-1,-1,-1,-1, -1,-1,-1,-1,-1,  -1, 1, 1,-1,-1, },
	
	{ 6,-1, 4, 4,-1,   7,-1,-1,-1,-1, -1,-1,-1,-1,-1,  -1, 1, 1,-1,-1, },
	
	{ 6, 6,-1,-1, 7,   7,-1, 2, 2,-1, -1, 3, 3,-1,-1,  -1,-1,-1,-1,-1, },
	
	{ 6, 6,-1,-1, 7,   7,-1,-1,-1,-1, -1,-1,-1,-1,-1,  -1,-1,-1, 0, 0, },
	
	{ 6,-1, 5, 5,-1,   7,-1,-1,-1,-1, -1,-1,-1,-1,-1,  -1,-1,-1, 0, 0, },
	
	{-1, 5, 5, 5, 5,  -1,-1,-1,-1,-1, -1,-1,-1,-1,-1,  -1,-1,-1,-1,-1, },
	
	/*
	{-1, 4,-1,-1, 2,  3,-1, 1,-1,-1},
	{ 6,-1, 7,-1,-1, -1, 1, 1, 0, 0},
	{-1, 5,-1,-1,-1, -1,-1,-1, 0, 0},
		*/
};

/*
最大触摸点数:10
指向每个点对应的button
*/
bool *(pointerHodler[10])={
	NULL
};

extern "C" {


//void __cxa_throw_bad_array_new_length() {}

Console *mConsole = NULL;

//存储屏幕宽度
int mScreenW = 0;
int mScreenH = 0;
int mScreenD = 0;

jobject mBitmapBuffer ;//使用图片缓冲区加快绘图速度

void *nesThread(void *data)
{
	while(mConsole!=NULL)
	{
		mConsole->StepFrame();
	}
	return NULL;
}

//在程序启动时调用
void onCreate()
{
	mBitmapBuffer = createBitmap(256,240);
	int length = 0;
	char *data;
	//data = (char *)readAllFromAssets("nestest.nes",&length);
	data = (char *)readAllFromAssets("chiseyaosai.nes",&length);
	//data = (char *)readAllFromAssets("hundouluo.nes",&length);
	mConsole = new Console(data,length);
	pthread_t pt;
	pthread_create(&pt,NULL,nesThread,NULL);
}

void down(float x,float y,int pointerId)
{
	float buttonw=mScreenW/20.0f;
	float buttonh=buttonw;
	float starty=mScreenH-buttonh*6;
	int a=x/buttonw;
	int b=(y-starty)/buttonh;
	if(a>=0&&a<20&&b>=0&&b<6&&keyMapper[b][a]>=0)
	{
		pointerHodler[pointerId]=&(mButton[keyMapper[b][a]]);//=true;
		*pointerHodler[pointerId]=true;
	}
	mConsole->SetButtons1(mButton);
}

void up(int pointerId)
{
	*pointerHodler[pointerId]=false;
	mConsole->SetButtons1(mButton);
}

//触摸事件调用
void onTouchEvent(int action,float x,float y,int index,int count,float pointersX[],float pointersY[],int pointersId[])
{
	switch(action&ACTION_MASK)
	{
	case ACTION_POINTER_DOWN:
	case ACTION_DOWN:
		down(pointersX[index],pointersY[index],pointersId[index]);
		break;
	case ACTION_POINTER_UP:
	case ACTION_UP:
		up(pointersId[index]);
		break;
	}
}

extern JNIEnv* mEnv;
void drawNesFrameToBitmap()
{
	unsigned int *pixs;
	AndroidBitmap_lockPixels(mEnv,mBitmapBuffer,(void**)&pixs);
	Image *image = mConsole->Buffer();
	unsigned int *bytes = image->bytes;
	int w = image->width;
	int h = image->height;
    for(int i = 0; i < h; i++) {
        for(int j = 0; j < w; j++) {
        	int pix = bytes[j+i*w];
        	pixs[j+i*w] =  0xff000000|pix ;
        }
    }
    AndroidBitmap_unlockPixels(mEnv,mBitmapBuffer);
}

//只能在这里绘图
void onDraw(int left,int top,int right,int bottom )
{
	drawNesFrameToBitmap();
	AndroidBitmapInfo info;
	getBitmapInfo(mBitmapBuffer,&info);
	float scale = mScreenW /(float) info.width;
	drawBitmap(mBitmapBuffer,0,0,info.width,info.height,0,0,info.width*scale,info.height*scale);
	
	float buttonw=mScreenW/20.0f;
	float buttonh=buttonw;
	float startx=0;
	float starty=mScreenH-buttonh*6;
	int i,j;
	setColor(RGB(0x00,0x00,0x00));
	for(i=0;i<6;i++)
	{
		for(j=0;j<20;j++)
		{
			if(keyMapper[i][j]>=0)
			{
				drawRect(startx+j*buttonw,starty+i*buttonh
						,startx+(1+j)*buttonw,starty+(1+i)*buttonh);
			}
		}
	}
}


//屏幕大小发生变化时被调用 ，程序在启动后会调用一次
void onSizeChange(int w,int h,int oldw,int oldh,float density)
{
	mScreenW = w;
	mScreenH = h;
}

long long proTime = 0;
//系统每1毫秒就会调用这个方法1次
void onLoopCall()
{
	long long time = currentTimeMillis();
	
	if(time - proTime>1000/20)
	{
		//mConsole->StepFrame();
		postInvalidate();
		proTime = time;
	}
}

//返回键被按下事件，如果 返回0则退出程序，
int onBackPressed()
{
	return 0;
}

//应用被暂停时调用，例如被后台运行
void onPause()
{
}

//应用被恢复时调用，例如从后台运行转为前台运行
void onResume()
{
	
}

//程序在被销毁时调用
void onDestroy()
{
	delete(mConsole);
	mConsole=NULL;
}
}
