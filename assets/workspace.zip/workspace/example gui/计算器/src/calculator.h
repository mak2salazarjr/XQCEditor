#ifndef CALCULATOR_H_
#define CALCULATOR_H_
#include "stack.h"
extern void initialCalculator();
extern double polandExpression(const char* );
extern void deleteCalculator();
#endif