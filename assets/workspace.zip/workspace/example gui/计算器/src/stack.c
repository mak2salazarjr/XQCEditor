#include "stack.h"
//初始化，返回空栈
PSTACK initialStack()
{
   PSTACK head = (PSTACK)malloc(sizeof(STACK));
   head->top = (PSNODE)malloc(sizeof(SNODE));
   head->bottom = head->top;
   head->top->Next = NULL;
   
   return head;
}
//压栈
int push(PSTACK head, double e)
{
   
   PSNODE pnew = (PSNODE)malloc(sizeof(SNODE));
   pnew->data = e;
   pnew->Next = head->top;
   head->top = pnew;
   return 1;
}
//判断栈是否为空
int stackLen(PSTACK head)
{
   if (head->top == head->bottom)
   {
      return 0;
   }
   else
   {
      return 1;
   }
}
//出栈
int pop(PSTACK head, double* t)
{
   if (stackLen(head) == 0)
   {
      return 0;
   }
   else
   {
	  PSNODE q = head->top;
	  *t = q->data;
	  head->top = q->Next;
	  free(q);
	  q = NULL;
      return 1;
   }
}
//清空栈
int clearStack(PSTACK head)
{
   if (stackLen(head) == 0)
   {
      return 0;
   }
   else
   {
	  PSNODE p = head->top;
	  PSNODE q = NULL;
	  while (p != head->bottom)
	  {
	     q = p->Next;
		 free(p);
		 p = q;
	  }
	  head->top = head->bottom;
      return 1;
   }
}
//销毁栈
void deleteStack(PSTACK* head)
{
   if (*head != NULL)
   {
      free((*head)->bottom);
	  free(*head);
	  *head = NULL;
   }
}