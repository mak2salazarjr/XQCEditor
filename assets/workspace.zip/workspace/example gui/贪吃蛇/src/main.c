#include "base.h"
//屏幕宽度
int mScreenW=0;
//屏幕高度
int mScreenH=0;
//屏幕像素密度
float mScreenD=1.0;
//蛇宽高
#define SWH 35
#define TEXTH 32//字体大小

int kzfx = 0;//控制方向
int foodx = 0;//食物坐标
int foody = 0;
int score = 0;//分数
typedef struct Node
{
    int x;
    int y;
    int w;
    int h;
    int r;
    int g;
    int b;
    struct Node* Prior;//指向前驱节点指针域
    struct Node* Next;//指向后继节点指针域
}NODE;

NODE* headnode = NULL;

void headnodeinit(NODE** );
void add_list(NODE*);
void drawSnake(NODE* );
void food();
void snakeScore();
void delte_list(NODE* );
void traverse_list(NODE*);
int init();
void start_timer();
void drawtype();
void foodrand();
int event(int, float, float);
int isCollRect(int, int, int, int, int, int, int, int);
//如果要使用LOGI,和LOGE请定义LOG_TAG这个宏
#define  LOG_TAG    "LOG_TAG"

//在程序启动时调用
void onCreate()
{
	setTextSize(TEXTH);
}

//触摸事件调用
void onTouchEvent(int action,float x,float y,int index,int count,float pointersX[],float pointersY[],int pointersId[])
{
	event(action, x, y);
}

//只能在这里绘图
void onDraw(int left,int top,int right,int bottom )
{
	drawColor(RGB(255, 255, 255));
	if (headnode != NULL)
	{
	   traverse_list(headnode);
	}
	drawtype();
	
}


//屏幕大小发生变化时被调用 ，程序在启动后会调用一次
void onSizeChange(int w,int h,int oldw,int oldh,float density)
{
	mScreenW=w;
	mScreenH=h;
	mScreenD=density;
	if (headnode == NULL)
	{
	   init();
	}
}

//系统每1毫秒就会调用这个方法1次
void onLoopCall()
{
	start_timer();
}

//初始化蛇头
void headnodeinit(NODE** p)
{
    *p = (struct Node* )malloc(sizeof(struct Node));
    memset(*p, 0, sizeof(struct Node));
    (*p)->Prior = (*p)->Next = *p;
    
    NODE* q = *p;
    int i = 0;
    for(i = 0; i < 3; i++)
    {
        add_list(q);     
    }

}
//遍历
void traverse_list(NODE* p)
{
    if(p->Next == p)
    {
        return;
    }
    else
    {
		
        NODE* q = p->Next;
        NODE per;
        per = *q;
        NODE t;
        per.r = 0;
		per.g = 255;
		per.b = 0;
        if(kzfx == 0)
        {   
            q->x += SWH;
			q->w += SWH;
        }
        else if(kzfx == 1)		
        {
            
            q->x -= SWH;
			q->w -= SWH;
        }
        else if(kzfx == 2)
        {
            q->y += SWH;
			q->h += SWH;
        }
        else
        {
            q->y -= SWH;
			q->h -= SWH;			
        }
        int x = q->x;
        int y = q->y;     
        q->r = 250;
		q->b = 0;
		q->g = 0;
		drawSnake(q);
        q = q->Next;
        while(q != p)
        { 
               t = *q;
               per.Next = q->Next;
			   *q = per;
               if((x == q->x && y == q->y) || x >= mScreenW || -1 > x || 
               y >= mScreenH-100 || -1 > y)
               {
				  delte_list(headnode);			  
                  headnodeinit(&headnode);
                  foodrand();
                  score = 0;
                  return;
               }
               per = t;
           
		   drawSnake(q);
           q = q->Next;
        }	
        snakeScore();
        food();
		 
        if(isCollRect(x, y, x+SWH, y+SWH, foodx, foody ,foodx+SWH, foody+SWH))
        {
           foodrand();
           add_list(p);
           score += 10;
        }   
    }
 
}
//食物坐标
void foodrand()
{
   do
   {
	   foodx = rand()%(mScreenW - (SWH+SWH));
       foody = rand()%(mScreenH - (SWH+SWH+100));
   }while(foodx <= SWH || foody <= SWH);
}

//清空链表
void delte_list(NODE* head)
{
    if(head->Next == head)
    {
     
        return;
    }
    else
    {
        NODE* p = head->Next;
        NODE* q = NULL;  
        while(p != head)
        {
            q = p->Next;
            free(p);
			p = q;		
        }
		free(head);
    }
 
}
//画蛇
void drawSnake(NODE* p)
{
    setColor(RGB(0, 0, 255));
	drawRect(p->x, p->y, p->w, p->h);
	setColor(RGB(p->r, p->g, p->b));
	drawRect(p->x+5, p->y+5, p->w-5, p->h-5); 
	 
}
//添加一节到尾部
void add_list(NODE* p)
{  
    NODE* Pnew = (struct Node* )malloc(sizeof(struct Node));

    Pnew->x = mScreenW/2;
    Pnew->y = mScreenH/2;
    Pnew->w = mScreenW/2+SWH;
    Pnew->h = mScreenH/2+SWH;
    Pnew->r = 0;
    Pnew->g = 255;
    Pnew->b = 0;

    p->Prior->Next = Pnew;
    Pnew->Next = p;
    Pnew->Prior = p->Prior;
    p->Prior = Pnew;
}
//食物
void food()
{
   setColor(RGB(0, 255, 0));
   drawRect(foodx, foody, foodx+SWH, foody+SWH);
   setColor(RGB(250, 0, 0));
   drawRect(foodx+5, foody+5, foodx+SWH-5, foody+SWH-5);
}
void drawtype()
{
	int i;
	float x = 0;
	char* text[4] = {"上", "下", "左", "右"};
	for (i = 0; i < 4; i++)
	{
	   setColor(RGB(0, 0, 0));
	   drawRect(x, mScreenH - 100, x+mScreenW/4, mScreenH);	 
	   setColor(RGB(255, 255, 255));	   
	   drawText(text[i], (x+mScreenW/8), mScreenH - 50);
	   x += mScreenW/4+10;
	}
}
void start_timer()
{
   	static long long proTime=0;
	//每200毫秒执行一次
	if(currentTimeMillis()-proTime>200)
	{
		proTime=currentTimeMillis();		
		postInvalidate();//通知系统重新绘图
	}
  
}
//判断是否吃到食物
int isCollRect(int x, int y, int w, int h, int x2, int y2, int w2, int h2)
{
    if ((w >= x2 && x <= w2) && (h >= y2 && y <= h2))
	{
	   return 1;
	}
	return 0;
}
//分数
void snakeScore()
{
    setColor(RGB(0, 0, 0));
	char buf[20];
    sprintf(buf, "得分:%d", score);	
	drawText(buf, 0, TEXTH);
}
//初始化
int init()
{
    kzfx = 0;
    score = 0;
    headnodeinit(&headnode);
    foodrand();
    return 0;
}
//触屏按键
int event(int type, float p1, float p2)
{
    if (ACTION_DOWN == type)
	{
	    float x = 0;
		int i;
		for (i = 1; i < 5; i++)
		{
		   if (p2 >= mScreenH-100 && x <= p1 && p1 <= x+mScreenW/4)
		   {
		      break;
		   }
		   x += mScreenW/4+10;
	    }
        if(1 == i)//上
        {
            if(headnode->Next->x != headnode->Next->Next->x)
            {kzfx = 3;}
        }
        if(2 == i)//下
        {
            if(headnode->Next->x != headnode->Next->Next->x)
            {kzfx = 2;}
        }
        if(3 == i)//左
        {
            if(headnode->Next->y != headnode->Next->Next->y)
            {kzfx = 1;}
        }
        if(4 == i)//右
        {
            if(headnode->Next->y != headnode->Next->Next->y)
            {kzfx = 0;}
        }
    
    
    }
    return 0;
}

//返回键被按下事件，如果 返回0则退出程序，
int onBackPressed()
{
	return 0;
}

//应用被暂停时调用，例如被后台运行
void onPause()
{
	showToastText("onPause",0);
}

//应用被恢复时调用，例如从后台运行转为前台运行
void onResume()
{
	showToastText("onResume",0);
}

//程序在被销毁时调用
void onDestroy()
{
	delte_list(headnode);
	exit(0);
}
