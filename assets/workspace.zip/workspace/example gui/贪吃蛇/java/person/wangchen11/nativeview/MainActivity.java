package person.wangchen11.nativeview;

//by wangchen11

import person.wangchen11.waps.Waps;
import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;

public class MainActivity extends Activity {
	NativeView mNativeView;
	LinearLayout mLinearLayout;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		NativeInterface.initActivity(this);
		mNativeView=new NativeView(this);
		mLinearLayout=new LinearLayout(this);
		mLinearLayout.setOrientation(LinearLayout.VERTICAL);
		Waps.init(this);
		LinearLayout layout=new LinearLayout(this);
		Waps.showBanner(this, layout);
		mLinearLayout.addView(layout);
		mLinearLayout.addView(mNativeView);
		setContentView(mLinearLayout);
	}
	
	@Override
	protected void onPause() {
		NativeInterface.onPause();
		super.onPause();
	}
	
	@Override
	protected void onResume() {
		NativeInterface.onResume();
		super.onResume();
	}
	
	@Override
	protected void onDestroy() {
		NativeInterface.destroy();
		super.onDestroy();
	}
	
	@Override
	public void onBackPressed() {
		if(NativeInterface.backPressed())
		{
			return ;
		}
		super.onBackPressed();
	}

}
