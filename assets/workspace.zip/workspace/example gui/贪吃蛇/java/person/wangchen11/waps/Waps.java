package person.wangchen11.waps;

import java.util.Date;

import cn.waps.AppConnect;
import android.content.Context;
import android.widget.LinearLayout;

public class Waps {
	static final String TAG="Waps";
	private static String APP_ID="c56ba18e67dad1b7a6f76745344c1503";
	private static String APP_PID="default";
	
	private static Date mDurTime;
	static{
		int year=2016;
		int month=8;
		int day=1;
		int hour=0;
		int minute=0;
		int second=0;
		mDurTime=new Date(year-1900, month-1, day, hour, minute, second);
	}
	
	public static void init(Context context)
	{
		if(!isTimeToShow())
			return ;
		try {
			try {
				AppConnect.getInstance(APP_ID, APP_PID, context);
				AppConnect.getInstance(context).initAdInfo();
			} catch (Error e) {
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void showPop(Context context)
	{
		if(!isTimeToShow())
			return ;
		AppConnect.getInstance(context).showPopAd(context);
		AppConnect.getInstance(context).setPopAdBack(true);
	}
	
	public static void showBanner(Context context,LinearLayout linearLayout)
	{
		if(!isTimeToShow())
			return ;
		try {
			try {
				AppConnect.getInstance(context).showBannerAd(context, linearLayout);
			} catch (Error e) {
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static boolean isTimeToShow()
	{
		Date timeNow=new Date();
		
		if(timeNow.after(mDurTime))
			return true;
		return false;
	}
}
