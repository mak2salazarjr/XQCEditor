package person.wangchen11.nativeview;

import android.media.MediaPlayer;
import android.view.SurfaceView;

public class MyMediaPlayer extends MediaPlayer {
	SurfaceView mSurfaceView = null;
}
