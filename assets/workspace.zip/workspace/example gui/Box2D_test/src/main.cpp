#include "base.h"
#include "Box2D/Box2D.h"

//如果要使用LOGI,和LOGE请定义LOG_TAG这个宏
#define  LOG_TAG    "LOG_TAG"


class MyWorld {
	b2World *world ;
	b2Vec2 gravity;
	b2Body *groundBody;
	b2PolygonShape groundBox;
	b2PolygonShape dynamicBox;
	b2Body* body;
	
public:
	MyWorld () :
		gravity(1.0f,-10.0f),
		groundBox(),
		dynamicBox()
	{
		world = new b2World(gravity);
		// Define the ground body.
		b2BodyDef groundBodyDef;
		groundBodyDef.position.Set(1.0f, -10.0f);
		groundBody = world->CreateBody(&groundBodyDef);
		groundBox.SetAsBox(500.0f,10.0f);
		groundBody->CreateFixture(&groundBox,0.2f);
		
		// Define the dynamic body. We set its position and call the body factory.
		b2BodyDef bodyDef;
		bodyDef.type = b2_dynamicBody;
		bodyDef.position.Set(0.0f, 400.0f);
		body = world->CreateBody(&bodyDef);
		
		// Define another box shape for our dynamic body.
		b2PolygonShape dynamicBox;
		dynamicBox.SetAsBox(1.0f, 1.0f);

		// Define the dynamic body fixture.
		b2FixtureDef fixtureDef;
		fixtureDef.shape = &dynamicBox;

		// Set the box density to be non-zero, so it will be dynamic.
		fixtureDef.density = 1.0f;

		// Override the default friction.
		fixtureDef.friction = 0.3f;
		
		fixtureDef.restitution = 0.8f;
		// Add the shape to the body.
		body->CreateFixture(&fixtureDef);

	}
	void step()
	{
		float32 timeStep = 1.0f / 60.0f;
		int32 velocityIterations = 6;
		int32 positionIterations = 2;
		// Instruct the world to perform a single step of simulation.
		// It is generally best to keep the time step and iterations fixed.
		world->Step(timeStep, velocityIterations, positionIterations);
	}
	
	void render()
	{
		b2Vec2 position = body->GetPosition();
		float32 angle = body->GetAngle();
		canvasSave();
		canvasRotate(position.x,position.y,angle);
		drawRect(position.x-10,position.y-10,position.x+10,position.y+10);
		canvasRestore();
	}
	~MyWorld()
	{
	}
};

MyWorld *mWorld;

extern "C" {

//在程序启动时调用
void onCreate()
{
	mWorld = new MyWorld();
}

//触摸事件调用
void onTouchEvent(int action,float x,float y,int index,int count,float pointersX[],float pointersY[],int pointersId[])
{
}

//只能在这里绘图
void onDraw(int left,int top,int right,int bottom )
{
	drawText("hello world!",100,100);
	mWorld->render();
}

//屏幕大小发生变化时被调用 ，程序在启动后会调用一次
void onSizeChange(int w,int h,int oldw,int oldh,float density)
{
}
long long preTime = 0;
//系统每1毫秒就会调用这个方法1次
void onLoopCall()
{
	long long time = currentTimeMillis();
	if(time-preTime>1000/60)
	{
		mWorld->step();
		postInvalidate();
		preTime = time;
	}
}

//返回键被按下事件，如果 返回0则退出程序，
int onBackPressed()
{
	return 0;
}

//应用被暂停时调用，例如被后台运行
void onPause()
{
}

//应用被恢复时调用，例如从后台运行转为前台运行
void onResume()
{
}

//程序在被销毁时调用
void onDestroy()
{
}

} // end extern C
