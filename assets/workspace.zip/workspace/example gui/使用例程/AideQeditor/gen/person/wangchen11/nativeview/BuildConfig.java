/** Automatically generated file. DO NOT MODIFY */
package person.wangchen11.nativeview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}