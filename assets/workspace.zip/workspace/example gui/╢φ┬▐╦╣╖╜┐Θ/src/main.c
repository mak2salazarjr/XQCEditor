#include "base.h"
#include <string.h>

//屏幕宽度
int mScreenW=0;
//屏幕高度
int mScreenH=0;
//屏幕像素密度
float mScreenD=1.0;

//如果要使用LOGI,和LOGE请定义LOG_TAG这个宏
#define  LOG_TAG    "LOG_TAG"

void drawGame();

//在程序启动时调用
void onCreate()
{
}

void onTouch(int action,float x, float y);
//触摸事件调用
void onTouchEvent(int action,float x,float y,int index,int count,float pointersX[],float pointersY[],int pointersId[])
{
	onTouch(action,x,y);
}


//只能在这里绘图
void onDraw(int left,int top,int right,int bottom )
{
	drawGame();
}


//屏幕大小发生变化时被调用 ，程序在启动后会调用一次
void onSizeChange(int w,int h,int oldw,int oldh,float density)
{
	mScreenW=w;
	mScreenH=h;
	mScreenD=density;
}

//系统每1毫秒就会调用这个方法1次
void loop();
void onLoopCall()
{
	loop();
}

//返回键被按下事件，如果 返回0则退出程序，
int onBackPressed()
{
	finish();
	return 0;
}

//应用被暂停时调用，例如被后台运行
void onPause()
{
}

//应用被恢复时调用，例如从后台运行转为前台运行
void onResume()
{
}

//程序在被销毁时调用
void onDestroy()
{
	//彻底退出程序，让系统将缓存也清除
	exit(0);
}



///////////以上为系统函数，必须实现////////////

#define GAME_WIDTH  9
#define GAME_HEIGHT 12

int mGameMap[GAME_HEIGHT][GAME_WIDTH]={0};
int mPlayerX;
int mPlayerY;
int mPlayer[3][3]={
	{0,0,0},
	{0,0,0},
	{0,0,0},
};
int mStarted=0;
int mMapType=0;
int mIndexOfMap=0;
int mType0Map[][3][3]={
	{
		{0,1,0},
		{0,1,0},
		{0,1,0},
	},
	{
		{0,0,0},
		{1,1,1},
		{0,0,0},
	},
};

int mType1Map[][3][3]={
	{
		{1,1,0},
		{0,1,0},
		{0,1,0},
	},
	{
		{0,0,1},
		{1,1,1},
		{0,0,0},
	},
	{
		{0,1,0},
		{0,1,0},
		{0,1,1},
	},
	{
		{0,0,0},
		{1,1,1},
		{1,0,0},
	},
};

int mType2Map[][3][3]={
	{
		{0,1,1},
		{0,1,0},
		{0,1,0},
	},
	{
		{0,0,0},
		{1,1,1},
		{0,0,1},
	},
	{
		{0,1,0},
		{0,1,0},
		{1,1,0},
	},
	{
		{1,0,0},
		{1,1,1},
		{0,0,0},
	},
};

int mType3Map[][3][3]={
	{
		{0,1,0},
		{1,1,0},
		{1,0,0},
	},
	{
		{0,0,0},
		{1,1,0},
		{0,1,1},
	},
};

int mType4Map[][3][3]={
	{
		{0,1,0},
		{0,1,1},
		{0,0,1},
	},
	{
		{0,0,0},
		{0,1,1},
		{1,1,0},
	},
};

int mType5Map[][3][3]={
	{
		{0,1,0},
		{1,1,0},
		{0,1,0},
	},
	{
		{0,1,0},
		{1,1,1},
		{0,0,0},
	},
	{
		{0,1,0},
		{0,1,1},
		{0,1,0},
	},
	{
		{0,0,0},
		{1,1,1},
		{0,1,0},
	},
};

int mType6Map[][3][3]={
	{
		{0,0,0},
		{1,1,0},
		{1,1,0},
	},
};

void drawGame()
{
	float space = mScreenW/(float)(2+GAME_WIDTH);
	
	setColor( RGB(240,180,200) );
	//画横线
	for(int y=0;y<=GAME_HEIGHT;y++)
	{
		drawLine( space,(y+1)*space,(GAME_WIDTH+1)*space,(y+1)*space);
	}
	//画竖线
	for(int x=0;x<=GAME_WIDTH;x++)
	{
		drawLine( (x+1)*space,space,(x+1)*space,(GAME_HEIGHT+1)*space);
	}
	//画出所有的背景方块
	for(int y=0;y<GAME_HEIGHT;y++)
	{
		for(int x=0;x<GAME_WIDTH;x++)
		{
			if(mGameMap[y][x]!=0)
			{
				drawRoundRect( (x+1)*space+mScreenD ,(y+1)*space+mScreenD,(x+2)*space-mScreenD,(y+2)*space-mScreenD ,space/4,space/4 );
			}
		}
	}
	//画出所有的玩家方块
	for(int y=0;y<3;y++)
	{
		for(int x=0;x<3;x++)
		{
			if(mPlayer[y][x]!=0)
			{
				drawRoundRect( (mPlayerX+x+1)*space+mScreenD ,(mPlayerY+y+1)*space+mScreenD,(mPlayerX+x+2)*space-mScreenD,(mPlayerY+y+2)*space-mScreenD ,space/4,space/4 );
			}
		}
	}
	
	//画向左移动的按钮
	drawRoundRect( 0+mScreenD ,mScreenH-56*mScreenD,mScreenW/3-mScreenD,mScreenH-mScreenD,space/4,space/4 );
	
	//画向左移动的按钮
	drawRoundRect( mScreenW/3+mScreenD ,mScreenH-56*mScreenD,mScreenW*2/3-mScreenD,mScreenH-mScreenD,space/4,space/4 );
	
	//画向左移动的按钮
	drawRoundRect( mScreenW*2/3+mScreenD ,mScreenH-56*mScreenD,mScreenW-mScreenD,mScreenH-mScreenD,space/4,space/4 );
	
}

//判断玩家的方块与背景方块是否有交集，0没有，1有
int hasSub()
{
	for(int y=0;y<3;y++)
	{
		for(int x=0;x<3;x++)
		{
			if(x+mPlayerX>=0 && x+mPlayerX<GAME_WIDTH 
				&& y+mPlayerY>=0 && y+mPlayerY<GAME_HEIGHT)//判断位置是否合法
			{
				if( (mGameMap[mPlayerY+y][mPlayerX+x]==1) && (mPlayer[y][x]==1))
					return 1;//有交集
			}
		}
	}
	return 0;//没有交集
}

//判断玩家是否越界，0没越界，1越界
int outOfBounds()
{
	
	for(int y=0;y<3;y++)
	{
		for(int x=0;x<3;x++)
		{
			if(x+mPlayerX>=0 && x+mPlayerX<GAME_WIDTH 
				/*&& y+mPlayerY>=0*/ && y+mPlayerY<GAME_HEIGHT)//判断位置是否合法
			{
			}
			else
			{
				if(mPlayer[y][x]==1)
					return 1;
			}
		}
	}
	return 0;
}

void endOfDown();
//定时下降时调用
void down()
{
	mPlayerY++;
	if(hasSub()||outOfBounds())
	{
		mPlayerY--;
		endOfDown();
	}
	//通知系统重新绘图
	postInvalidate();
}

void clearFullLines();
void newDown();
//一次下降结束
void endOfDown()
{
	//将玩家方块复制到背景方块
	for(int y=0;y<3;y++)
	{
		for(int x=0;x<3;x++)
		{
			if(x+mPlayerX>=0 && x+mPlayerX<GAME_WIDTH 
				&& y+mPlayerY>=0 && y+mPlayerY<GAME_HEIGHT)//判断位置是否合法
			{
				if(mPlayer[y][x]==1)
					mGameMap[mPlayerY+y][mPlayerX+x]=mPlayer[y][x];
			}
		}
	}
	clearFullLines();
	newDown();
	if(hasSub())
	{
		mStarted=0;
		showToastText("Game Over!",0);
	}
}

void copyMapToPlayer(int type,int index);
void newDown()
{
	mPlayerX=(GAME_WIDTH-3)/2;
	mPlayerY=-2;
	//rand()生成随机数
	copyMapToPlayer(rand()%7,0);
}

void copyMapToPlayer(int type,int index)
{
	int length=1;
	int *map=NULL;
	switch(type)
	{
		case 1:
			map=(int *)&mType1Map;
			length=4;
			break;
		case 2:
			map=(int *)&mType2Map;
			length=4;
			break;
		case 3:
			map=(int *)&mType3Map;
			length=2;
			break;
		case 4:
			map=(int *)&mType4Map;
			length=2;
			break;
		case 5:
			map=(int *)&mType5Map;
			length=4;
			break;
		case 6:
			map=(int *)&mType6Map;
			length=1;
			break;
		case 0:
		default:
			type=0;
			map=(int *)&mType0Map;
			length=2;
			break;
	}
	if(index>=length)
		index=0;
	mIndexOfMap=index;
	mMapType=type;
	memcpy(mPlayer,map+index*3*3,sizeof(mPlayer));
}

//清除一行
void clearLine(int line)
{
	for(int y=line-1;y>=0;y--)
	{
		for(int x=0;x<GAME_WIDTH;x++)
		{
			mGameMap[y+1][x]=mGameMap[y][x];
		}
	}
	for(int x=0;x<GAME_WIDTH;x++)
	{
		mGameMap[0][x]=0;
	}
}

//清除所有完整的行
void clearFullLines()
{
	for(int y=GAME_HEIGHT-1;y>=0;y--)
	{
		int isFull=1;//
		for(int x=0;x<GAME_WIDTH;x++)
		{
			if(mGameMap[y][x]==0)
			{
				isFull=0;
				break;
			}
		}
		if(isFull!=0)
		{
			clearLine(y);
			y++;
		}
	}
}

//变形
void trans()
{
	int index=mIndexOfMap;
	//变换
	copyMapToPlayer(mMapType,index+1);
	if(hasSub()||outOfBounds())
	{//如果越界或者不合法，则恢复到之前的状态
		copyMapToPlayer(mMapType,index);
	}
	//通知系统重新绘图
	postInvalidate();
	
}

void loop()
{
	static long long proTime=0;
	//每500毫秒执行一次
	if(currentTimeMillis()-proTime>500)
	{
		proTime=currentTimeMillis();
		if(mStarted)
			down();
	}
}

void left()
{
	mPlayerX--;
	if(hasSub()||outOfBounds())
	{
		mPlayerX++;
	}
	//通知系统重新绘图
	postInvalidate();
}

void right()
{
	mPlayerX++;
	if(hasSub()||outOfBounds())
	{
		mPlayerX--;
	}
	//通知系统重新绘图
	postInvalidate();
}

void newGame()
{
	//重置背景
	memset(&mGameMap,0,sizeof(mGameMap));
	//设置随机数种子
	srand((int)currentTimeMillis());
	//重置玩家
	newDown();
}

void onTouch(int action,float x ,float y)
{
	if(action==ACTION_DOWN)
	{
		if(!mStarted)
		{
			mStarted=1;
			newGame();
		}
		else
		if(y>(mScreenH-mScreenD*56))
		{
			if(x<mScreenW/3)
			{//左
				left();
			}
			else
			if(x<mScreenW*2/3)
			{//中
				trans();
			}
			else
			{//右
				right();
			}
		}
	}
}