OUT_FILE="test.elf"

rm -f $OUT_FILE
gcc test.c -lc -static -o $OUT_FILE
if [ -f $OUT_FILE ]
then
	echo "编译成功！"
else
	echo "编译失败！"
fi


OUT_FILE="testcpp.elf"

rm -f $OUT_FILE
gcc testcpp.cpp  -static -o $OUT_FILE
if [ -f $OUT_FILE ]
then
	echo "编译成功！"
else
	echo "编译失败！"
fi


