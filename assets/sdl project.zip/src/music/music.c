#include <jni.h>
#include <stdlib.h>
#include <string.h>
#include "../SDL2/SDL.h"
#include "music.h"

/**
 * 这是SDL的媒体播放器补丁，弥补SDL无法播放MP3,ogg...的问题。
 * 欢迎加入快写代码官方群:136898517。
 * 望尘11作品。
 *
 * This file is a musicplayer patch for (快写代码  or c4droid) SDL project.
 * [wangchen11 software]
 */


/*
 * This function is import from SDL_android.c at line 525.
 * We need the JNIEnv to call java functions.
 */
extern JNIEnv* Android_JNI_GetEnv(void);

struct MediaPlayer_st
{
	jobject javaMediaPlayer;
	SDL_RWops * ops;
};


static jclass getMediaPlayerClass(JNIEnv* env)
{
	const char * mediaPlayerClassName = "android/media/MediaPlayer";
	return (*env)->FindClass(env,mediaPlayerClassName);
}

static jclass getAssetFileDescriptorClass(JNIEnv* env)
{
	const char * assetFileDescriptorClassName = "android/content/res/AssetFileDescriptor";
	return (*env)->FindClass(env,assetFileDescriptorClassName);
}


/**
 * 创建一个媒体播放器对象
 */
MediaPlayer * createMediaPlayer(void)
{
	JNIEnv* env = Android_JNI_GetEnv();
	jclass mediaPlayerClass = getMediaPlayerClass(env);
	jmethodID mediaPlayerInitMethoID = (*env)->GetMethodID(env,mediaPlayerClass,"<init>","()V");
	// FIXME: jmethodID need free?

	MediaPlayer *mediaPlayer = (MediaPlayer*)malloc(sizeof(MediaPlayer));
	memset(mediaPlayer,0,sizeof(MediaPlayer));

	jobject obj = (*env)->NewObject(env,mediaPlayerClass,mediaPlayerInitMethoID);
	mediaPlayer->javaMediaPlayer = (*env)->NewGlobalRef(env,obj);
	(*env)->DeleteLocalRef(env,obj);

	(*env)->DeleteLocalRef(env,mediaPlayerClass);
	return mediaPlayer;
}

/**
 * 删除一个媒体播放器对象
 */
jboolean deleteMediaPlayer(MediaPlayer * mediaPlayer)
{
	JNIEnv* env = Android_JNI_GetEnv();
	jclass mediaPlayerClass = getMediaPlayerClass(env);

	if(mediaPlayer->javaMediaPlayer!=NULL)
	{
		jmethodID mediaPlayerMethod = (*env)->GetMethodID(env,mediaPlayerClass,"release","()V");
		// FIXME: jmethodID need free?
		(*env)->CallVoidMethod(env,mediaPlayer->javaMediaPlayer,mediaPlayerMethod);
		(*env)->DeleteGlobalRef(env,mediaPlayer->javaMediaPlayer);
		mediaPlayer->javaMediaPlayer = NULL;
	}

	if(mediaPlayer->ops!=NULL)
	{
		SDL_RWclose(mediaPlayer->ops);
		mediaPlayer->ops = NULL;
	}
	free(mediaPlayer);

	(*env)->DeleteLocalRef(env,mediaPlayerClass);
	return jtrue;
}

/**
 * 设置媒体播放器的数据源
 */
jboolean mediaPlayerSetSource(MediaPlayer * mediaPlayer,const char *path)
{
	SDL_LogError(0,"mediaPlayerSetSource");
	if(mediaPlayer->ops!=NULL)
	{
		SDL_LogError(0,"is already set source!");
		// is already set source!
		// just return false.
		return jfalse;
	}

	if(mediaPlayer->javaMediaPlayer==NULL)
	{
		SDL_LogError(0,"mediaPlayer create failed!it is impossible!");
		// mediaPlayer create failed!it is impossible!
		// just return false.
		return jfalse;
	}

	mediaPlayer->ops = SDL_RWFromFile(path,"rb");
	if(mediaPlayer->ops==NULL)
	{
		SDL_LogError(0,"can't open file:%s",SDL_GetError());
		//can't open file
		return jfalse;
	}

	JNIEnv* env = Android_JNI_GetEnv();
	jclass mediaPlayerClass = getMediaPlayerClass(env);


	if(mediaPlayer->ops->type == SDL_RWOPS_STDFILE)
	{
		jmethodID mediaPlayerMethod = (*env)->GetMethodID(env,mediaPlayerClass,"setDataSource","(Ljava/lang/String;)V");
		// FIXME: jmethodID need free?
		jstring file = (*env)->NewStringUTF(env,path);
		(*env)->CallVoidMethod(env,mediaPlayer->javaMediaPlayer,mediaPlayerMethod,file);
		(*env)->DeleteLocalRef(env,file);
	}
	else
	if(mediaPlayer->ops->type == SDL_RWOPS_JNIFILE)
	{
		jmethodID mediaPlayerMethod = (*env)->GetMethodID(env,mediaPlayerClass,"setDataSource","(Ljava/io/FileDescriptor;JJ)V");

		jclass assetFileDescriptorClass = getAssetFileDescriptorClass(env);
		jmethodID getFileDescriptorMethod = (*env)->GetMethodID(env,assetFileDescriptorClass,"getFileDescriptor","()Ljava/io/FileDescriptor;");
		// FIXME: jmethodID need free?
		jobject fileDescriptor = (*env)->CallObjectMethod(env,mediaPlayer->ops->hidden.androidio.assetFileDescriptorRef,getFileDescriptorMethod);

		// FIXME: jmethodID need free?
		(*env)->CallVoidMethod(env,mediaPlayer->javaMediaPlayer,mediaPlayerMethod,
				fileDescriptor,
				(jlong)mediaPlayer->ops->hidden.androidio.offset,
				(jlong)mediaPlayer->ops->hidden.androidio.size);

		(*env)->DeleteLocalRef(env,fileDescriptor);
		(*env)->DeleteLocalRef(env,assetFileDescriptorClass);
	}

	(*env)->DeleteLocalRef(env,mediaPlayerClass);
	return jtrue;
}


/**
 * 准备播放媒体文件
 */
jboolean mediaPlayerPrepare(MediaPlayer * mediaPlayer)
{
	if(mediaPlayer->javaMediaPlayer==NULL)
	{
		// mediaPlayer create failed!it is impossible!
		// just return false.
		return jfalse;
	}

	if(mediaPlayer->ops==NULL)
	{
		// not set scouce
		// just return false.
		return jfalse;
	}

	JNIEnv* env = Android_JNI_GetEnv();
	jclass mediaPlayerClass = getMediaPlayerClass(env);
	jmethodID mediaPlayerMethod = (*env)->GetMethodID(env,mediaPlayerClass,"prepare","()V");
	// FIXME: jmethodID need free?
	(*env)->CallVoidMethod(env,mediaPlayer->javaMediaPlayer,mediaPlayerMethod);

	(*env)->DeleteLocalRef(env,mediaPlayerClass);
	return jtrue;
}


/**
 * 开始播放媒体文件
 */
jboolean mediaPlayerStart(MediaPlayer * mediaPlayer)
{
	if(mediaPlayer->javaMediaPlayer==NULL)
	{
		// mediaPlayer create failed!it is impossible!
		// just return false.
		return jfalse;
	}

	if(mediaPlayer->ops==NULL)
	{
		// not set scouce
		// just return false.
		return jfalse;
	}
	JNIEnv* env = Android_JNI_GetEnv();
	jclass mediaPlayerClass = getMediaPlayerClass(env);
	jmethodID mediaPlayerMethod = (*env)->GetMethodID(env,mediaPlayerClass,"start","()V");
	// FIXME: jmethodID need free?
	(*env)->CallVoidMethod(env,mediaPlayer->javaMediaPlayer,mediaPlayerMethod);

	(*env)->DeleteLocalRef(env,mediaPlayerClass);
	return jtrue;
}


/**
 * 停止播放媒体文件
 */
jboolean mediaPlayerStop(MediaPlayer * mediaPlayer)
{
	if(mediaPlayer->javaMediaPlayer==NULL)
	{
		// mediaPlayer create failed!it is impossible!
		// just return false.
		return jfalse;
	}

	if(mediaPlayer->ops==NULL)
	{
		// not set scouce
		// just return false.
		return jfalse;
	}

	JNIEnv* env = Android_JNI_GetEnv();
	jclass mediaPlayerClass = getMediaPlayerClass(env);
	jmethodID mediaPlayerMethod = (*env)->GetMethodID(env,mediaPlayerClass,"stop","()V");
	// FIXME: jmethodID need free?
	(*env)->CallVoidMethod(env,mediaPlayer->javaMediaPlayer,mediaPlayerMethod);

	(*env)->DeleteLocalRef(env,mediaPlayerClass);
	return jtrue;
}


/**
 * 重置媒体播放器
 */
jboolean mediaPlayerReset(MediaPlayer * mediaPlayer)
{
	if(mediaPlayer->javaMediaPlayer==NULL)
	{
		// mediaPlayer create failed!it is impossible!
		// just return false.
		return jfalse;
	}

	if(mediaPlayer->ops==NULL)
	{
		// not set scouce
		// just return false.
		return jfalse;
	}

	JNIEnv* env = Android_JNI_GetEnv();
	jclass mediaPlayerClass = getMediaPlayerClass(env);
	jmethodID mediaPlayerMethod = (*env)->GetMethodID(env,mediaPlayerClass,"reset","()V");
	// FIXME: jmethodID need free?
	(*env)->CallVoidMethod(env,mediaPlayer->javaMediaPlayer,mediaPlayerMethod);

	(*env)->DeleteLocalRef(env,mediaPlayerClass);
	return jtrue;
}


/**
 * 暂停播放器
 */
jboolean mediaPlayerPause(MediaPlayer * mediaPlayer)
{
	if(mediaPlayer->javaMediaPlayer==NULL)
	{
		// mediaPlayer create failed!it is impossible!
		// just return false.
		return jfalse;
	}

	if(mediaPlayer->ops==NULL)
	{
		// not set scouce
		// just return false.
		return jfalse;
	}

	JNIEnv* env = Android_JNI_GetEnv();
	jclass mediaPlayerClass = getMediaPlayerClass(env);
	jmethodID mediaPlayerMethod = (*env)->GetMethodID(env,mediaPlayerClass,"pause","()V");
	// FIXME: jmethodID need free?
	(*env)->CallVoidMethod(env,mediaPlayer->javaMediaPlayer,mediaPlayerMethod);

	(*env)->DeleteLocalRef(env,mediaPlayerClass);
	return jtrue;
}

/**
 * 设置是否循环播放
 */
jboolean mediaPlayerSetLooping(MediaPlayer * mediaPlayer,jboolean looping)
{
	if(mediaPlayer->javaMediaPlayer==NULL)
	{
		// mediaPlayer create failed!it is impossible!
		// just return false.
		return jfalse;
	}

	if(mediaPlayer->ops==NULL)
	{
		// not set scouce
		// just return false.
		return jfalse;
	}

	JNIEnv* env = Android_JNI_GetEnv();
	jclass mediaPlayerClass = getMediaPlayerClass(env);
	jmethodID mediaPlayerMethod = (*env)->GetMethodID(env,mediaPlayerClass,"setLooping","(Z)V");
	// FIXME: jmethodID need free?
	(*env)->CallVoidMethod(env,mediaPlayer->javaMediaPlayer,mediaPlayerMethod,looping);

	(*env)->DeleteLocalRef(env,mediaPlayerClass);
	return jtrue;
}


/**
 * 判断当前是否循环播放
 */
jboolean mediaPlayerIsLooping(MediaPlayer * mediaPlayer)
{
	if(mediaPlayer->javaMediaPlayer==NULL)
	{
		// mediaPlayer create failed!it is impossible!
		// just return false.
		return jfalse;
	}

	if(mediaPlayer->ops==NULL)
	{
		// not set scouce
		// just return false.
		return jfalse;
	}

	JNIEnv* env = Android_JNI_GetEnv();
	jclass mediaPlayerClass = getMediaPlayerClass(env);
	jmethodID mediaPlayerMethod = (*env)->GetMethodID(env,mediaPlayerClass,"isLooping","()Z");
	// FIXME: jmethodID need free?

	jboolean ret = (*env)->CallBooleanMethod(env,mediaPlayer->javaMediaPlayer,mediaPlayerMethod);

	(*env)->DeleteLocalRef(env,mediaPlayerClass);
	return ret;
}

/**
 * 判断当前是否正在播放
 */
jboolean mediaPlayerIsPlaying(MediaPlayer * mediaPlayer)
{
	if(mediaPlayer->javaMediaPlayer==NULL)
	{
		// mediaPlayer create failed!it is impossible!
		// just return false.
		return jfalse;
	}

	if(mediaPlayer->ops==NULL)
	{
		// not set scouce
		// just return false.
		return jfalse;
	}

	JNIEnv* env = Android_JNI_GetEnv();
	jclass mediaPlayerClass = getMediaPlayerClass(env);
	jmethodID mediaPlayerMethod = (*env)->GetMethodID(env,mediaPlayerClass,"isPlaying","()Z");
	// FIXME: jmethodID need free?

	jboolean ret = (*env)->CallBooleanMethod(env,mediaPlayer->javaMediaPlayer,mediaPlayerMethod);

	(*env)->DeleteLocalRef(env,mediaPlayerClass);
	return ret;
}

/**
 * 设置音量
 */
jboolean mediaPlayerSetVolume(MediaPlayer * mediaPlayer,float leftVolume,float rightVolume)
{
	if(mediaPlayer->javaMediaPlayer==NULL)
	{
		// mediaPlayer create failed!it is impossible!
		// just return false.
		return jfalse;
	}

	if(mediaPlayer->ops==NULL)
	{
		// not set scouce
		// just return false.
		return jfalse;
	}

	JNIEnv* env = Android_JNI_GetEnv();
	jclass mediaPlayerClass = getMediaPlayerClass(env);
	jmethodID mediaPlayerMethod = (*env)->GetMethodID(env,mediaPlayerClass,"setVolume","(ff)V");
	// FIXME: jmethodID need free?
	(*env)->CallVoidMethod(env,mediaPlayer->javaMediaPlayer,mediaPlayerMethod,leftVolume,rightVolume);

	(*env)->DeleteLocalRef(env,mediaPlayerClass);
	return jtrue;
}


/**
 * 设置播放位置
 */
jboolean mediaPlayerSeekTo(MediaPlayer * mediaPlayer,int ms)
{
	if(mediaPlayer->javaMediaPlayer==NULL)
	{
		// mediaPlayer create failed!it is impossible!
		// just return false.
		return jfalse;
	}

	if(mediaPlayer->ops==NULL)
	{
		// not set scouce
		// just return false.
		return jfalse;
	}

	JNIEnv* env = Android_JNI_GetEnv();
	jclass mediaPlayerClass = getMediaPlayerClass(env);
	jmethodID mediaPlayerMethod = (*env)->GetMethodID(env,mediaPlayerClass,"seekTo","(I)V");
	// FIXME: jmethodID need free?
	(*env)->CallVoidMethod(env,mediaPlayer->javaMediaPlayer,mediaPlayerMethod,ms);

	(*env)->DeleteLocalRef(env,mediaPlayerClass);
	return jtrue;
}


/**
 * 获取持续时间
 */
int mediaPlayerGetDuration(MediaPlayer * mediaPlayer)
{
	if(mediaPlayer->javaMediaPlayer==NULL)
	{
		// mediaPlayer create failed!it is impossible!
		// just return false.
		return jfalse;
	}

	if(mediaPlayer->ops==NULL)
	{
		// not set scouce
		// just return false.
		return jfalse;
	}

	JNIEnv* env = Android_JNI_GetEnv();
	jclass mediaPlayerClass = getMediaPlayerClass(env);
	jmethodID mediaPlayerMethod = (*env)->GetMethodID(env,mediaPlayerClass,"getDuration","()I");
	// FIXME: jmethodID need free?
	jint ret = (*env)->CallIntMethod(env,mediaPlayer->javaMediaPlayer,mediaPlayerMethod);

	(*env)->DeleteLocalRef(env,mediaPlayerClass);
	return ret;
}


/**
 * 获取当前播放的时间
 */
int mediaPlayerGetCurrentPosition(MediaPlayer * mediaPlayer)
{
	if(mediaPlayer->javaMediaPlayer==NULL)
	{
		// mediaPlayer create failed!it is impossible!
		// just return false.
		return jfalse;
	}

	if(mediaPlayer->ops==NULL)
	{
		// not set scouce
		// just return false.
		return jfalse;
	}

	JNIEnv* env = Android_JNI_GetEnv();
	jclass mediaPlayerClass = getMediaPlayerClass(env);
	jmethodID mediaPlayerMethod = (*env)->GetMethodID(env,mediaPlayerClass,"getCurrentPosition","()I");
	// FIXME: jmethodID need free?
	jint ret = (*env)->CallIntMethod(env,mediaPlayer->javaMediaPlayer,mediaPlayerMethod);

	(*env)->DeleteLocalRef(env,mediaPlayerClass);
	return ret;
}












