/**
 * 这是SDL的媒体播放器补丁，弥补SDL无法播放MP3,ogg...的问题。
 * 欢迎加入快写代码官方群:136898517。
 * 望尘11作品。
 *
 * This file is a musicplayer patch for (快写代码  or c4droid) SDL project.
 * [wangchen11 software]
 */

/**
 * 你可以这样使用
 * MediaPlayer * mediaPlayer = createMediaPlayer();
 * mediaPlayerSetSource(mediaPlayer,"music.mp3");
 * mediaPlayerPrepare(mediaPlayer);
 * mediaPlayerStart(mediaPlayer);
 *
 * 使用完后需要这样释放
 * deleteMediaPlayer(mediaPlayer);
 */

#ifndef MUSIC_H
#define MUSIC_H

#include <jni.h>

#define jfalse 0
#define jtrue  (!jfalse)


#ifdef __cplusplus
extern "C" {
#endif

typedef struct MediaPlayer_st MediaPlayer;

/**
 * 创建一个媒体播放器对象
 */
MediaPlayer * createMediaPlayer();

/**
 * 删除一个媒体播放器对象
 */
jboolean deleteMediaPlayer(MediaPlayer * mediaPlayer);


/**
 * 设置媒体播放器的数据源
 */
jboolean mediaPlayerSetSource(MediaPlayer * mediaPlayer,const char *path);

/**
 * 准备播放媒体文件
 */
jboolean mediaPlayerPrepare(MediaPlayer * mediaPlayer);

/**
 * 开始播放媒体文件
 */
jboolean mediaPlayerStart(MediaPlayer * mediaPlayer);

/**
 * 停止播放媒体文件
 */
jboolean mediaPlayerStop(MediaPlayer * mediaPlayer);

/**
 * 重置媒体播放器
 */
jboolean mediaPlayerReset(MediaPlayer * mediaPlayer);

/**
 * 暂停播放器
 */
jboolean mediaPlayerPause(MediaPlayer * mediaPlayer);

/**
 * 设置是否循环播放
 */
jboolean mediaPlayerSetLooping(MediaPlayer * mediaPlayer,jboolean looping);

/**
 * 判断当前是否循环播放
 */
jboolean mediaPlayerIsLooping(MediaPlayer * mediaPlayer);

/**
 * 判断当前是否正在播放
 */
jboolean mediaPlayerIsPlaying(MediaPlayer * mediaPlayer);

/**
 * 设置音量
 */
jboolean mediaPlayerSetVolume(MediaPlayer * mediaPlayer,float leftVolume,float rightVolume);

/**
 * 设置播放位置
 */
jboolean mediaPlayerSeekTo(MediaPlayer * mediaPlayer,int ms);

/**
 * 获取持续时间
 */
int mediaPlayerGetDuration(MediaPlayer * mediaPlayer);

/**
 * 获取当前播放的时间
 */
int mediaPlayerGetCurrentPosition(MediaPlayer * mediaPlayer);

#ifdef __cplusplus
}
#endif

#endif

