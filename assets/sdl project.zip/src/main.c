
/*
文件名:nc_1_2.cpp
标识:SDL2教程源码
描述:加载图片

作者:冯世昌
创建时间:2014年12月5日
联系方式:
		QQ:670337693
		Email:
				dxkite@163.com
				670337693@qq.com
版权申明:	 
a.使用者可以随时利用本文件创建其它文件.
b.使用者可以随时修改文件有效代码内容.
c.使用者不得修改版权申明，版权归文件创建者所有.
d.文件使用者本人承担使用本文档后的所有法律责任,本件创建者不为您的文件内容承担任何法律责任.
e.如有修改或重写发布时请保留本部分内容
Copyright © DXkite 2014 all rights reserved.
*/
//加载非bmp图片
#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"
#include "music/music.h"

// 窗口
SDL_Window *Window = NULL;
// 窗口表面
SDL_Surface *WindowScreen = NULL;
// 图片表面
SDL_Surface *Surface = NULL;

int Init()
{
	SDL_Init(SDL_INIT_VIDEO);
	//初始化IMG
	IMG_Init(IMG_INIT_PNG);
	// 创建窗口
	Window = SDL_CreateWindow("SDL_Window", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 240, 400, SDL_WINDOW_SHOWN);
	if (Window == NULL)
		return -1;

	// 获取Window的表面
	WindowScreen = SDL_GetWindowSurface(Window);
	if (WindowScreen == NULL)
		return -2;
	return 0;
}

int LoadSurface()
{
//加载图片
	Surface = IMG_Load("c1.png");
	if (Surface == NULL)
		return -1;
	return 0;
}

void Destroy()
{
	SDL_FreeSurface(WindowScreen);
	SDL_FreeSurface(Surface);
	SDL_DestroyWindow(Window);
	IMG_Quit();
	SDL_Quit();
}


int main(int args, char *argv[])
{
	MediaPlayer * mediaPlayer = createMediaPlayer();
	mediaPlayerSetSource(mediaPlayer,"music.wav");
	mediaPlayerPrepare(mediaPlayer);
	mediaPlayerStart(mediaPlayer);
	
	//初始化
	if (Init() != 0)
		return -1;
	//加载图片
	if (LoadSurface() != 0)
		return -2;
	//粘贴表面
	SDL_BlitScaled(Surface, NULL, WindowScreen, NULL);
	//更新窗口
	SDL_UpdateWindowSurface(Window);
	SDL_Delay(10000);
	Destroy();
	return 0;
}