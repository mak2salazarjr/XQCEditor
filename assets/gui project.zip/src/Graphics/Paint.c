#include "../base.h"
#include "Paint.h"

#define LOG_TAG "Paint"

static jclass getClass(JNIEnv* env,const char * className)
{
	return (*env)->FindClass(env,className);
}

static jclass getPaintClass(JNIEnv* env)
{
	return getClass(env,"android/graphics/Paint");
}


//创建画笔对象，用完后需要通过deletePaint释放
Paint newPaint()
{
	JNIEnv* env = Android_JNI_GetEnv();
	jclass clazz = getPaintClass(env);
	jmethodID methoID = (*env)->GetMethodID( env,clazz,"<init>","()V" );
	jobject obj = (*env)->NewObject(env,clazz,methoID);
	Paint paint = (*env)->NewGlobalRef(env,obj);
	(*env)->DeleteLocalRef(env,obj);
	(*env)->DeleteLocalRef(env,clazz);
	return paint;
}

//释放画笔对象
void deletePaint(Paint thiz)
{
	if(thiz==NULL)
	{
		LOGE("deletePaint thiz==NULL");
		return ;
	}
	JNIEnv* env = Android_JNI_GetEnv();
	(*env)->DeleteGlobalRef(env,thiz);
}

//设置画笔颜色
void Paint_setColor(Paint thiz,int color)
{
	if(thiz==NULL)
	{
		LOGE("Paint_setColor thiz==NULL");
		return ;
	}
	JNIEnv* env = Android_JNI_GetEnv();
	jclass clazz = getPaintClass(env);
	jmethodID methoID = (*env)->GetMethodID(env,clazz,"setColor","(I)V");
	(*env)->DeleteLocalRef(env,clazz);
	(*env)->CallVoidMethod(env,thiz,methoID,color);
}

//获取画笔颜色
int  Paint_getColor(Paint thiz)
{
	if(thiz==NULL)
	{
		LOGE("Paint_getColor thiz==NULL");
		return 0;
	}
	JNIEnv* env = Android_JNI_GetEnv();
	jclass clazz = getPaintClass(env);
	jmethodID methoID = (*env)->GetMethodID(env,clazz,"getColor","()I");
	(*env)->DeleteLocalRef(env,clazz);
	return (*env)->CallIntMethod(env,thiz,methoID);
}

//设置画笔尺寸
void Paint_setTextSize(Paint thiz,float size)
{
	if(thiz==NULL)
	{
		LOGE("Paint_setColor thiz==NULL");
		return ;
	}
	JNIEnv* env = Android_JNI_GetEnv();
	jclass clazz = getPaintClass(env);
	jmethodID methoID = (*env)->GetMethodID(env,clazz,"setTextSize","(F)V");
	(*env)->DeleteLocalRef(env,clazz);
	(*env)->CallVoidMethod(env,thiz,methoID,size);
}

//得到画笔尺寸
float  Paint_getTextSize(Paint thiz)
{
	if(thiz==NULL)
	{
		LOGE("Paint_getTextSize thiz==NULL");
		return 0;
	}
	JNIEnv* env = Android_JNI_GetEnv();
	jclass clazz = getPaintClass(env);
	jmethodID methoID = (*env)->GetMethodID(env,clazz,"getTextSize","()F");
	(*env)->DeleteLocalRef(env,clazz);
	return (*env)->CallFloatMethod(env,thiz,methoID);
}

//设置画笔粗细
void Paint_setStrokeWidth(Paint thiz,float width)
{
	if(thiz==NULL)
	{
		LOGE("Paint_setStrokeWidth thiz==NULL");
		return ;
	}
	JNIEnv* env = Android_JNI_GetEnv();
	jclass clazz = getPaintClass(env);
	jmethodID methoID = (*env)->GetMethodID(env,clazz,"setStrokeWidth","(F)V");
	(*env)->DeleteLocalRef(env,clazz);
	(*env)->CallVoidMethod(env,thiz,methoID,width);
}

//得到画笔粗细
float Paint_getStrokeWidth(Paint thiz)
{
	if(thiz==NULL)
	{
		LOGE("Paint_getStrokeWidth thiz==NULL");
		return 0;
	}
	JNIEnv* env = Android_JNI_GetEnv();
	jclass clazz = getPaintClass(env);
	jmethodID methoID = (*env)->GetMethodID(env,clazz,"getStrokeWidth","()F");
	(*env)->DeleteLocalRef(env,clazz);
	return (*env)->CallFloatMethod(env,thiz,methoID);
}

//设置画笔类型中空，还是填满
void Paint_setStyle(Paint thiz,int style)
{
	if(thiz==NULL)
	{
		LOGE("Paint_setStyle thiz==NULL");
		return ;
	}
	JNIEnv* env = Android_JNI_GetEnv();
	jclass clazz = getPaintClass(env);
	jmethodID methoID = (*env)->GetMethodID(env,clazz,"setStyle","(Landroid/graphics/Paint$Style;)V");
	(*env)->DeleteLocalRef(env,clazz);
	jclass enumClazz = getClass(env,"android/graphics/Paint$Style");

	jfieldID enumFieldId = NULL;
	switch(style){
	case STYLE_FILL:
		enumFieldId = (*env)->GetStaticFieldID(env,enumClazz,"FILL","Landroid/graphics/Paint$Style;");
		break;
	case STYLE_FILL_AND_STROKE:
		enumFieldId = (*env)->GetStaticFieldID(env,enumClazz,"FILL_AND_STROKE","Landroid/graphics/Paint$Style;");
		break;
	case STYLE_STROKE:
	default:
		enumFieldId = (*env)->GetStaticFieldID(env,enumClazz,"STROKE","Landroid/graphics/Paint$Style;");
		break;
	}
	jobject enumObj = (*env)->GetStaticObjectField(env,enumClazz,enumFieldId);
	(*env)->CallVoidMethod(env,thiz,methoID,enumObj);
	(*env)->DeleteLocalRef(env,enumObj);
	(*env)->DeleteLocalRef(env,enumClazz);

}

//设置字体样式
void Paint_setTypeface(Paint thiz,int typeface)
{
	if(thiz==NULL)
	{
		LOGE("Paint_setTypeface thiz==NULL");
		return ;
	}
	JNIEnv* env = Android_JNI_GetEnv();
	jclass clazz = getPaintClass(env);
	jmethodID methoID = (*env)->GetMethodID(env,clazz,"setTypeface","(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;");
	(*env)->DeleteLocalRef(env,clazz);
	jclass enumClazz = getClass(env,"android/graphics/Typeface");

	jfieldID enumFieldId = NULL;
	switch(typeface){
	case TYPEFACE_DEFAULT_BOLD:
		enumFieldId = (*env)->GetStaticFieldID(env,enumClazz,"DEFAULT_BOLD","Landroid/graphics/Typeface;");
		break;
	case TYPEFACE_SANS_SERIF:
		enumFieldId = (*env)->GetStaticFieldID(env,enumClazz,"SANS_SERIF","Landroid/graphics/Typeface;");
		break;
	case TYPEFACE_SERIF:
		enumFieldId = (*env)->GetStaticFieldID(env,enumClazz,"SERIF","Landroid/graphics/Typeface;");
		break;
	case TYPEFACE_MONOSPACE:
		enumFieldId = (*env)->GetStaticFieldID(env,enumClazz,"MONOSPACE","Landroid/graphics/Typeface;");
		break;
	case TYPEFACE_DEFAULT:
	default:
		enumFieldId = (*env)->GetStaticFieldID(env,enumClazz,"DEFAULT","Landroid/graphics/Typeface;");
		break;
	}
	jobject enumObj = (*env)->GetStaticObjectField(env,enumClazz,enumFieldId);
	jobject oldObj = (*env)->CallObjectMethod(env,thiz,methoID,enumObj);
	if(oldObj!=NULL)
		(*env)->DeleteLocalRef(env,oldObj);
	(*env)->DeleteLocalRef(env,enumObj);
	(*env)->DeleteLocalRef(env,enumClazz);
}

//测量文本宽度
float Paint_measureText(Paint thiz,const char *text)
{
	jstring str = createJString(text);
	float ret = Paint_measureJString(thiz,str);
	deleteJString(str);
	return ret;
}

//测量文本宽度
float Paint_measureJString(Paint thiz,jstring str)
{
	return Paint_measureJStringEx(thiz,str,0,lengthOfJString(str));
}

//测量文本宽度
float Paint_measureJStringEx(Paint thiz,jstring str,int start,int end)
{
	if(thiz==NULL)
	{
		LOGE("Paint_measureJStringEx thiz==NULL");
		return 0;
	}
	JNIEnv* env = Android_JNI_GetEnv();
	jclass clazz = getPaintClass(env);
	jmethodID methoID = (*env)->GetMethodID(env,clazz,"measureText","(Ljava/lang/String;II)F");
	(*env)->DeleteLocalRef(env,clazz);
	return (*env)->CallFloatMethod(env,thiz,methoID,str,start,end);

}

float Paint_getDescent(Paint thiz)
{
	if(thiz==NULL)
	{
		LOGE("Paint_getDescent thiz==NULL");
		return 0;
	}
	JNIEnv* env = Android_JNI_GetEnv();
	jclass clazz = getPaintClass(env);
	jmethodID methoID = (*env)->GetMethodID(env,clazz,"getFontMetrics","()Landroid/graphics/Paint$FontMetrics;");
	(*env)->DeleteLocalRef(env,clazz);
	jobject metrics = (*env)->CallObjectMethod(env,thiz,methoID);
	jclass  metricsClass = (*env)->GetObjectClass(env,metrics);

	jfieldID metricsFieldId = (*env)->GetFieldID(env,metricsClass,"descent","F");
	float ret = (*env)->GetFloatField(env,metrics,metricsFieldId);
	(*env)->DeleteLocalRef(env,metricsClass);
	(*env)->DeleteLocalRef(env,metrics);
	return ret;
}

