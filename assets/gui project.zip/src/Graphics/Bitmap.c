#include "Bitmap.h"
#include "../base.h"

//创建一个位图
Bitmap newBitmap(int width,int height)
{
	return createBitmap(width,height);
}

//得到位图的宽度
int Bitmap_getWidth(Bitmap thiz)
{
	AndroidBitmapInfo info;
	getBitmapInfo(thiz,&info);
	return info.width;
}

//得到位图的高度
int Bitmap_getHeight(Bitmap thiz)
{
	AndroidBitmapInfo info;
	getBitmapInfo(thiz,&info);
	return info.height;
}

//锁定位图的像素，并返回像素，返回的像素数据可以编辑 且不需要free，记得使用Bitmap_unlockPixels解锁
unsigned int *Bitmap_lockPixels(Bitmap thiz)
{
	JNIEnv* env = Android_JNI_GetEnv();
	unsigned int *pixs = NULL;
	AndroidBitmap_lockPixels(env,thiz,(void**)&pixs);
	return pixs;
}

//解锁像素点
void Bitmap_unlockPixels(Bitmap thiz)
{
	JNIEnv* env = Android_JNI_GetEnv();
	AndroidBitmap_unlockPixels(env,thiz);
}

extern jboolean saveBitmapToFile(Bitmap bitmap,const char *path,int format,int quality);

//将位图保存到文件，返回0:成功，非0：失败
int Bitmap_saveToFile(Bitmap thiz,const char *path)
{
	return Bitmap_saveToFileEx(thiz,path,FORMAT_PNG,100);
}

//将位图保存到文件，返回0:成功，非0：失败
//format:FORMAT_JPEG,FORMAT_JPEG
//quality:[0-100]
int Bitmap_saveToFileEx(Bitmap thiz,const char *path,int format,int quality)
{
	if(saveBitmapToFile(thiz,path,format,quality)){
		return 0;
	}
	return -1;
}
