#查看其它程序的日志如要root权限，请使用root方式运行该脚本

#清除之前的log
logcat -c

#设置过滤的TAG
export LOG_TAG="LOG_TAG"

#过滤日志
logcat | grep -E "$LOG_TAG|AndroidRuntime|art/runtime/thread.cc"
