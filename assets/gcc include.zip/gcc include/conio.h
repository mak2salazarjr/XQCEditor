/*
 *	conio.h
 *	Author: Jakash3
 */

#ifndef CONIO_H
#define CONIO_H
 
#include <stdio.h>
#include <unistd.h>
#include <termios.h>
#include <sys/select.h>

// wangchen11 patch begin 
// use '__attribute__((unused))' to 
// suppress warning :function define but unused 
__attribute__((unused))
static void terminal_lnbuf(int yn) {
   struct termios oldt, newt;
   tcgetattr(0, &oldt);
   newt = oldt;
   if (!yn) newt.c_lflag &= ~ICANON;
   else newt.c_lflag |= ICANON;
   tcsetattr(0, TCSANOW, &newt);
}
 
__attribute__((unused))
static void terminal_echo(int yn) {
   struct termios oldt, newt;
   tcgetattr(0, &oldt);
   newt = oldt;
   if (!yn) newt.c_lflag &= ~ECHO;
   else newt.c_lflag |= ECHO;
   tcsetattr(0, TCSANOW, &newt);
}
	 
__attribute__((unused))
static void gotoxy(int x, int y) { printf("\x1B[%d;%df", y, x); }

__attribute__((unused))
static void _gotoxy(int x,int y) {gotoxy(x,y);}
	 
__attribute__((unused))
static void clrscr() { printf("\x1B[2J\x1B[0;0f"); }

__attribute__((unused))
static void _clrscr() {clrscr();}
	 
__attribute__((unused))
static int getch() {
   register int ch;
   terminal_lnbuf(0);
   terminal_echo(0);
   ch = getchar();
   terminal_lnbuf(1);
   terminal_echo(1);
   return ch;
}

__attribute__((unused))
static int _getch() {return getch();}
	 
	 
__attribute__((unused))
static int getche() {
   register int ch;
   terminal_lnbuf(0);
   ch = getchar();
   terminal_lnbuf(1);
   return ch;
}

__attribute__((unused))
static int _getche() {return getche();}

__attribute__((unused))
static int kbhit() {
   register int ret;
   fd_set fds;
   terminal_lnbuf(0);
   terminal_echo(0);
   struct timeval tv;
   tv.tv_sec = 0;
   tv.tv_usec = 0;
   FD_ZERO(&fds);
   FD_SET(0, &fds);
   select(1, &fds, 0, 0, &tv);
   ret = FD_ISSET(0, &fds);
   terminal_lnbuf(1);
   terminal_echo(1);
   return ret;
}

__attribute__((unused))
static int _kbhit() {return kbhit();}

// wangchen11 patch end 

#endif