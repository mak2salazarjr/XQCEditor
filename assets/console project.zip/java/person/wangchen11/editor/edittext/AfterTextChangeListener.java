package person.wangchen11.editor.edittext;

public interface AfterTextChangeListener {
	public void afterTextChange();
}
