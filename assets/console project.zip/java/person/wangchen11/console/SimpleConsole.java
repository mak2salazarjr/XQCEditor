package person.wangchen11.console;

public class SimpleConsole {

}
