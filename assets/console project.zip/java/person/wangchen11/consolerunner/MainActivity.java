package person.wangchen11.consolerunner;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import person.wangchen11.console.ConsoleView;
import android.app.Activity;
import android.content.Context;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		State.init(this);
		freeResourceIfNeed();
		String runnable=getRunnableFilePath(this);
		freeFile(this,"elf.elf",runnable);
		String cmd="";
		cmd+="chmod 777 "+runnable+"\n";
		cmd+="cd "+getRunnablePath(this)+"\n";
		cmd+=runnable+"\n";
		ConsoleView consoleView=new ConsoleView(this);
		consoleView.getConsole().execute(cmd);
		setContentView(consoleView);
	}
	public static String getRunnablePath(Context context)
	{
		return context.getFilesDir().getAbsolutePath();
	}
	public static String getRunnableFilePath(Context context)
	{
		return getRunnablePath(context)+"/elf.elf";
	}
	public static boolean freeFile(Context context,String assetsName,String fileTo)
	{
		try {
			OutputStream outputStream=new FileOutputStream(new File(fileTo));
			try {
				InputStream inputStream=context.getAssets().open(assetsName);
				byte data[] = new byte[4096];
				int readLen=0;
				while( ( readLen=inputStream.read(data))>0 )
				{
					outputStream.write(data,0,readLen);
				}
				inputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			try {
				outputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	private void freeResourceIfNeed()
	{
		if(State.isUpdated())
		{
			freeAllAssets("",getRunnablePath(this));
		}
		State.save(this);
	}
	private void freeAllAssets(String assetsDir,String toDirs)
	{
		AssetManager assetManager = getAssets();
		try {
			String []names=assetManager.list(assetsDir);
			if(names!=null)
			{
				for(String name:names)
				{
					Log.i("@@", ""+name);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
